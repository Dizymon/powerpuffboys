# DentalCare Connect - Vanilla HTML/CSS/JavaScript Version

A fully functional dental appointment booking website built with pure HTML, CSS, and JavaScript (no frameworks or dependencies required).

## Features

### For Patients:
- Browse licensed dentists by specialization
- View detailed dentist profiles with credentials and availability
- Book appointments by selecting date and time slots
- Track appointment approval status
- Manage appointment requests

### For Dentists:
- Review and manage appointment requests
- Approve or reject appointments with notes
- Edit professional profile and credentials
- Manage availability schedule
- View all appointments (pending, approved, rejected)

## File Structure

```
public/
├── index.html                          # Main HTML file
├── css/
│   └── styles.css                      # All CSS styles
├── js/
│   ├── app.js                          # Application entry point
│   ├── utils/
│   │   └── icons.js                    # SVG icons
│   ├── data/
│   │   └── mockData.js                 # Mock data and services
│   ├── services/
│   │   ├── authService.js              # Authentication service
│   │   └── router.js                   # Client-side router
│   ├── components/
│   │   ├── header.js                   # Header component
│   │   └── footer.js                   # Footer component
│   └── pages/
│       ├── home.js                     # Home page
│       ├── about.js                    # About page
│       ├── contact.js                  # Contact page
│       ├── login.js                    # Login page
│       ├── patient/
│       │   ├── dashboard.js            # Patient dashboard
│       │   ├── appointments.js         # Browse dentists
│       │   ├── dentist-detail.js       # Dentist profile view
│       │   ├── register-appointment.js # Book appointment
│       │   └── approval-status.js      # Track status
│       └── dentist/
│           ├── dashboard.js            # Dentist dashboard
│           ├── manage-appointments.js  # Manage appointments
│           └── profile.js              # Edit profile
```

## How to Run

### Option 1: Using a Local Web Server

1. **Using Python:**
   ```bash
   cd public
   python3 -m http.server 8000
   ```
   Then open http://localhost:8000 in your browser

2. **Using Node.js (http-server):**
   ```bash
   npm install -g http-server
   cd public
   http-server -p 8000
   ```
   Then open http://localhost:8000 in your browser

3. **Using PHP:**
   ```bash
   cd public
   php -S localhost:8000
   ```
   Then open http://localhost:8000 in your browser

### Option 2: Using Live Server (VS Code)

1. Install the "Live Server" extension in VS Code
2. Right-click on `public/index.html`
3. Select "Open with Live Server"

## How to Use

### For Patients:

1. **Login:**
   - Go to the Login page
   - Select "Patient" tab
   - Enter any email and password
   - Click "Login as Patient"

2. **Browse Dentists:**
   - Navigate to "Browse Dentists" from the dashboard
   - Filter by specialization if needed
   - Click on a dentist to view their profile

3. **Book an Appointment:**
   - From a dentist's profile, click "Book Appointment"
   - Fill in your details
   - Select a day and time slot
   - Submit the request

4. **Track Status:**
   - Go to "Appointment Status" to see all your appointments
   - View pending, approved, or rejected appointments
   - See dentist notes

### For Dentists:

1. **Login:**
   - Go to the Login page
   - Select "Dentist" tab
   - Enter any email and password
   - Click "Login as Dentist"

2. **Review Appointments:**
   - View pending requests on the dashboard
   - Click "Approve" or "Reject"
   - Add notes for the patient

3. **Manage Appointments:**
   - Go to "Manage Appointments"
   - Filter by status (all, pending, approved, rejected)
   - Delete appointments if needed

4. **Edit Profile:**
   - Go to "Edit Profile"
   - Update your professional information
   - Manage your availability schedule
   - Add or remove days and time slots

## Design Theme

The application uses a clean **olive green and cream white** aesthetic:
- **Primary Color:** #6B7F5E (Olive Green)
- **Background:** #FDFCFA (Cream White)
- **Accent Color:** #8FA582 (Light Olive)
- Professional and calming design suitable for healthcare

## Features Implemented

- ✅ Client-side routing (no page reloads)
- ✅ Role-based authentication (Patient/Dentist)
- ✅ Protected routes
- ✅ Local storage for session persistence
- ✅ Mock data services (can be replaced with real API calls)
- ✅ Responsive design (mobile-friendly)
- ✅ CRUD operations for appointments
- ✅ Filter and search functionality
- ✅ Modal dialogs
- ✅ Form validation
- ✅ SVG icons (no external dependencies)

## Browser Compatibility

Works in all modern browsers:
- Chrome (latest)
- Firefox (latest)
- Safari (latest)
- Edge (latest)

## No Dependencies!

This application uses zero external libraries or frameworks:
- No React, Vue, or Angular
- No jQuery
- No Bootstrap or Tailwind CDN
- No icon libraries
- Pure vanilla JavaScript, HTML, and CSS

## Customization

### Changing Colors:
Edit the CSS variables in `/public/css/styles.css`:
```css
:root {
    --primary: #6B7F5E;        /* Change primary color */
    --accent: #8FA582;          /* Change accent color */
    --background: #FDFCFA;      /* Change background */
}
```

### Adding Real API:
Replace the mock services in `/public/js/data/mockData.js` with real API calls:
```javascript
// Example: Replace mock with fetch
getAll: async () => {
    const response = await fetch('/api/dentists');
    return response.json();
}
```

### Adding Database:
Replace localStorage in `/public/js/services/authService.js` with real authentication API calls.

## Future Enhancements

Possible additions:
- Email notifications
- Calendar integration
- Payment processing
- Real-time updates with WebSockets
- File upload for medical records
- Multi-language support
- Dark mode
- Print appointment receipts

## License

This project is open source and available for educational purposes.

## Support

For questions or issues, contact: info@dentalcareconnect.com

---

**Note:** This is a demo application with mock data. In production, replace the mock services with real backend APIs and database connections.
