// Main Application Entry Point
document.addEventListener('DOMContentLoaded', () => {
    // Register all routes
    
    // Public routes
    Router.register('/', HomePage.render);
    Router.register('/about', AboutPage.render);
    Router.register('/contact', ContactPage.render);
    Router.register('/login', LoginPage.render);
    
    // Patient routes
    Router.register('/patient/dashboard', PatientDashboardPage.render);
    Router.register('/patient/appointments', PatientAppointmentsPage.render);
    Router.register('/patient/dentist/:dentistId', PatientDentistDetailPage.render);
    Router.register('/patient/register-appointment/:dentistId', RegisterAppointmentPage.render);
    Router.register('/patient/approval-status', ApprovalStatusPage.render);
    
    // Dentist routes
    Router.register('/dentist/dashboard', DentistDashboardPage.render);
    Router.register('/dentist/appointments', ManageAppointmentsPage.render);
    Router.register('/dentist/profile', DentistProfilePage.render);
    
    // Initialize router
    Router.init();
});
