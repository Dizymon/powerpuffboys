// Footer Component
const FooterComponent = {
    render: () => {
        return `
            <footer>
                <div class="container">
                    <p>&copy; 2026 DentalCare Connect. All rights reserved.</p>
                    <p class="mt-2">Contact: info@dentalcareconnect.com | (555) 123-4567</p>
                </div>
            </footer>
        `;
    }
};
