// Header Component
const HeaderComponent = {
    renderPublic: () => {
        return `
            <header>
                <div class="container py-4">
                    <div class="flex items-center justify-between">
                        <a href="/" data-link class="flex items-center gap-2" style="text-decoration: none; color: inherit;">
                            <div class="logo-circle">
                                ${Icons.calendar}
                            </div>
                            <h1 class="text-xl">HealthCare Connect</h1>
                        </a>
                        <nav class="flex gap-6">
                            <a href="/" data-link>Home</a>
                            <a href="/about" data-link>About</a>
                            <a href="/contact" data-link>Contact</a>
                            <a href="/login" data-link>
                                <button class="btn btn-primary">Login</button>
                            </a>
                        </nav>
                    </div>
                </div>
            </header>
        `;
    },
    
    renderPatient: () => {
        const user = AuthService.getCurrentUser();
        return `
            <header>
                <div class="container py-4">
                    <div class="flex items-center justify-between">
                        <a href="/patient/dashboard" data-link class="flex items-center gap-2" style="text-decoration: none; color: inherit;">
                            <div class="logo-circle">
                                ${Icons.calendar}
                            </div>
                            <h1 class="text-xl">HealthlCare Connect</h1>
                        </a>
                        <div class="flex items-center gap-4">
                            <span>Welcome, ${user?.name}</span>
                            <button class="btn btn-outline btn-sm" onclick="handleLogout()">
                                Logout
                            </button>
                        </div>
                    </div>
                </div>
            </header>
            <div class="nav-menu">
                <div class="container">
                    <nav class="flex gap-2">
                        <a href="/patient/dashboard" data-link class="${Router.getCurrentRoute() === '/patient/dashboard' ? 'active' : ''}">Dashboard</a>
                        <a href="/patient/appointments" data-link class="${Router.getCurrentRoute() === '/patient/appointments' ? 'active' : ''}">Browse Dentists</a>
                        <a href="/patient/approval-status" data-link class="${Router.getCurrentRoute() === '/patient/approval-status' ? 'active' : ''}">Appointment Status</a>
                    </nav>
                </div>
            </div>
        `;
    },
    
    renderDentist: () => {
        const user = AuthService.getCurrentUser();
        return `
            <header>
                <div class="container py-4">
                    <div class="flex items-center justify-between">
                        <a href="/dentist/dashboard" data-link class="flex items-center gap-2" style="text-decoration: none; color: inherit;">
                            <div class="logo-circle">
                                ${Icons.calendar}
                            </div>
                            <h1 class="text-xl">HealthlCare Connect</h1>
                        </a>
                        <div class="flex items-center gap-4">
                            <span>Welcome, ${user?.name}</span>
                            <button class="btn btn-outline btn-sm" onclick="handleLogout()">
                                Logout
                            </button>
                        </div>
                    </div>
                </div>
            </header>
            <div class="nav-menu">
                <div class="container">
                    <nav class="flex gap-2">
                        <a href="/dentist/dashboard" data-link class="${Router.getCurrentRoute() === '/dentist/dashboard' ? 'active' : ''}">Dashboard</a>
                        <a href="/dentist/appointments" data-link class="${Router.getCurrentRoute() === '/dentist/appointments' ? 'active' : ''}">Manage Appointments</a>
                        <a href="/dentist/profile" data-link class="${Router.getCurrentRoute() === '/dentist/profile' ? 'active' : ''}">Edit Profile</a>
                    </nav>
                </div>
            </div>
        `;
    }
};

// Global logout handler
function handleLogout() {
    AuthService.logout();
    Router.navigate('/');
}
