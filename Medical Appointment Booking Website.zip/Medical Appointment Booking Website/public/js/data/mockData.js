// Mock data for the dental appointment system

// Mock dentists data
const mockDentists = [
    {
        id: 'dentist-1',
        name: 'Dr. Sarah Johnson',
        specialization: 'General Dentistry',
        credentials: 'DDS, Member of American Dental Association',
        description: 'Experienced general dentist with over 10 years of practice. Specializes in preventive care, fillings, and cosmetic dentistry.',
        availability: [
            { day: 'Monday', slots: ['9:00 AM', '10:00 AM', '2:00 PM', '3:00 PM'] },
            { day: 'Wednesday', slots: ['9:00 AM', '11:00 AM', '1:00 PM', '4:00 PM'] },
            { day: 'Friday', slots: ['10:00 AM', '2:00 PM', '3:00 PM'] }
        ]
    },
    {
        id: 'dentist-2',
        name: 'Dr. Michael Chen',
        specialization: 'Orthodontics',
        credentials: 'DMD, Board Certified Orthodontist',
        description: 'Specialist in braces, aligners, and corrective dental procedures. Dedicated to creating beautiful, healthy smiles.',
        availability: [
            { day: 'Tuesday', slots: ['9:00 AM', '10:30 AM', '2:00 PM', '3:30 PM'] },
            { day: 'Thursday', slots: ['9:00 AM', '11:00 AM', '1:00 PM', '3:00 PM'] },
            { day: 'Saturday', slots: ['9:00 AM', '10:00 AM', '11:00 AM'] }
        ]
    },
    {
        id: 'dentist-3',
        name: 'Dr. Emily Rodriguez',
        specialization: 'Oral Surgery',
        credentials: 'DDS, Oral & Maxillofacial Surgery Specialist',
        description: 'Expert in wisdom teeth removal, dental implants, and complex oral surgical procedures.',
        availability: [
            { day: 'Monday', slots: ['8:00 AM', '11:00 AM', '2:00 PM'] },
            { day: 'Tuesday', slots: ['8:00 AM', '1:00 PM', '3:00 PM'] },
            { day: 'Thursday', slots: ['8:00 AM', '10:00 AM', '2:00 PM'] }
        ]
    },
    {
        id: 'dentist-4',
        name: 'Dr. James Williams',
        specialization: 'Pediatric Dentistry',
        credentials: 'DDS, Pediatric Dental Specialist',
        description: 'Caring dentist specialized in children\'s dental health. Creates a comfortable and fun environment for young patients.',
        availability: [
            { day: 'Monday', slots: ['10:00 AM', '11:00 AM', '3:00 PM', '4:00 PM'] },
            { day: 'Wednesday', slots: ['10:00 AM', '2:00 PM', '3:00 PM', '4:00 PM'] },
            { day: 'Friday', slots: ['9:00 AM', '10:00 AM', '11:00 AM', '2:00 PM'] }
        ]
    }
];

// In-memory storage for appointments
let appointments = [
    {
        id: 'apt-1',
        patientId: 'patient-1',
        dentistId: 'dentist-1',
        patientName: 'John Doe',
        contactNumber: '555-0123',
        email: 'john.doe@example.com',
        gender: 'Male',
        age: '32',
        reason: 'Regular checkup and cleaning',
        date: '2026-02-24',
        timeSlot: '10:00 AM',
        status: 'approved',
        dentistNotes: 'Looking forward to your appointment!'
    }
];

// Appointment service functions
const AppointmentService = {
    getAll: () => [...appointments],
    
    getByPatientId: (patientId) => {
        return appointments.filter(apt => apt.patientId === patientId);
    },
    
    getByDentistId: (dentistId) => {
        return appointments.filter(apt => apt.dentistId === dentistId);
    },
    
    getPending: (dentistId) => {
        return appointments.filter(apt => apt.dentistId === dentistId && apt.status === 'pending');
    },
    
    create: (appointment) => {
        const newAppointment = {
            ...appointment,
            id: `apt-${Date.now()}`
        };
        appointments.push(newAppointment);
        return newAppointment;
    },
    
    updateStatus: (id, status, notes) => {
        const index = appointments.findIndex(apt => apt.id === id);
        if (index !== -1) {
            appointments[index] = {
                ...appointments[index],
                status,
                dentistNotes: notes
            };
            return appointments[index];
        }
        return null;
    },
    
    delete: (id) => {
        const index = appointments.findIndex(apt => apt.id === id);
        if (index !== -1) {
            appointments.splice(index, 1);
            return true;
        }
        return false;
    }
};

// Dentist service functions
const DentistService = {
    getAll: () => [...mockDentists],
    
    getById: (id) => {
        return mockDentists.find(dentist => dentist.id === id);
    },
    
    updateProfile: (id, updates) => {
        const index = mockDentists.findIndex(d => d.id === id);
        if (index !== -1) {
            mockDentists[index] = { ...mockDentists[index], ...updates };
            return mockDentists[index];
        }
        return null;
    }
};
