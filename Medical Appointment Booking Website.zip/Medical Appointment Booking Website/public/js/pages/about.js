// About Page
const AboutPage = {
    render: () => {
        const app = document.getElementById('app');
        app.innerHTML = `
            <div class="min-h-screen">
                ${HeaderComponent.renderPublic()}
                
                <div class="container max-w-4xl px-4 py-12">
                    <h1 class="text-4xl mb-6 text-center">About DentalCare Connect</h1>
                    
                    <div class="card mb-8">
                        <div class="card-content p-6">
                            <h2 class="mb-4">Our Mission</h2>
                            <p class="text-muted mb-4">
                                DentalCare Connect is dedicated to making dental care more accessible and convenient for everyone. 
                                We bridge the gap between patients and licensed dental professionals through our easy-to-use 
                                online appointment booking platform.
                            </p>
                            <p class="text-muted">
                                Our platform allows patients to browse qualified dentists by specialization, view their 
                                availability, and book appointments that fit their schedule—all from the comfort of their home.
                            </p>
                        </div>
                    </div>

                    <div class="card mb-8">
                        <div class="card-content p-6">
                            <h2 class="mb-4">For Patients</h2>
                            <ul style="list-style: disc; margin-left: 1.5rem;">
                                <li class="mb-2 text-muted">Browse licensed dentists by specialization</li>
                                <li class="mb-2 text-muted">View detailed dentist profiles and credentials</li>
                                <li class="mb-2 text-muted">Check real-time availability</li>
                                <li class="mb-2 text-muted">Submit appointment requests online</li>
                                <li class="mb-2 text-muted">Track appointment approval status</li>
                                <li class="mb-2 text-muted">Manage all your dental appointments in one place</li>
                            </ul>
                        </div>
                    </div>

                    <div class="card mb-8">
                        <div class="card-content p-6">
                            <h2 class="mb-4">For Dentists</h2>
                            <ul style="list-style: disc; margin-left: 1.5rem;">
                                <li class="mb-2 text-muted">Create and manage your professional profile</li>
                                <li class="mb-2 text-muted">Set your availability and time slots</li>
                                <li class="mb-2 text-muted">Review patient appointment requests</li>
                                <li class="mb-2 text-muted">Approve or reject appointments with notes</li>
                                <li class="mb-2 text-muted">Manage your appointment schedule efficiently</li>
                                <li class="mb-2 text-muted">Communicate directly with patients</li>
                            </ul>
                        </div>
                    </div>

                    <div class="card">
                        <div class="card-content p-6">
                            <h2 class="mb-4">Our Commitment</h2>
                            <p class="text-muted">
                                We are committed to maintaining the highest standards of quality and security. All dentists 
                                on our platform are verified licensed professionals with valid credentials. We prioritize 
                                patient privacy and data security, ensuring all information is handled with care and 
                                confidentiality.
                            </p>
                        </div>
                    </div>

                    <div class="text-center mt-8">
                        <a href="/login" data-link>
                            <button class="btn btn-primary btn-lg">Get Started Today</button>
                        </a>
                    </div>
                </div>

                ${FooterComponent.render()}
            </div>
        `;
    }
};
