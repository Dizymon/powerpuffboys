// Contact Page
const ContactPage = {
    render: () => {
        const app = document.getElementById('app');
        app.innerHTML = `
            <div class="min-h-screen">
                ${HeaderComponent.renderPublic()}
                
                <div class="container max-w-4xl px-4 py-12">
                    <h1 class="text-4xl mb-6 text-center">Contact Us</h1>
                    <p class="text-center text-muted mb-12">
                        Have questions? We're here to help! Reach out to us through any of the following channels.
                    </p>

                    <div class="grid md:grid-cols-2 gap-8 mb-12">
                        <div class="card">
                            <div class="card-content p-6 text-center">
                                <div class="icon-circle mx-auto mb-4" style="background: rgba(107, 127, 94, 0.2);">
                                    <div style="color: var(--primary);">${Icons.mail}</div>
                                </div>
                                <h3 class="mb-2">Email Us</h3>
                                <p class="text-muted mb-2">General Inquiries:</p>
                                <p style="color: var(--primary);">info@dentalcareconnect.com</p>
                                <p class="text-muted mt-4 mb-2">Support:</p>
                                <p style="color: var(--primary);">support@dentalcareconnect.com</p>
                            </div>
                        </div>

                        <div class="card">
                            <div class="card-content p-6 text-center">
                                <div class="icon-circle mx-auto mb-4" style="background: rgba(107, 127, 94, 0.2);">
                                    <div style="color: var(--primary);">${Icons.phone}</div>
                                </div>
                                <h3 class="mb-2">Call Us</h3>
                                <p class="text-muted mb-2">Main Line:</p>
                                <p style="color: var(--primary);">(555) 123-4567</p>
                                <p class="text-muted mt-4 mb-2">Support Line:</p>
                                <p style="color: var(--primary);">(555) 123-4568</p>
                            </div>
                        </div>

                        <div class="card">
                            <div class="card-content p-6 text-center">
                                <div class="icon-circle mx-auto mb-4" style="background: rgba(107, 127, 94, 0.2);">
                                    <div style="color: var(--primary);">${Icons.mapPin}</div>
                                </div>
                                <h3 class="mb-2">Visit Us</h3>
                                <p class="text-muted">
                                    123 Dental Street<br>
                                    Healthcare District<br>
                                    Medical City, MC 12345<br>
                                    United States
                                </p>
                            </div>
                        </div>

                        <div class="card">
                            <div class="card-content p-6 text-center">
                                <div class="icon-circle mx-auto mb-4" style="background: rgba(107, 127, 94, 0.2);">
                                    <div style="color: var(--primary);">${Icons.clock}</div>
                                </div>
                                <h3 class="mb-2">Business Hours</h3>
                                <p class="text-muted">
                                    Monday - Friday<br>
                                    9:00 AM - 6:00 PM<br>
                                    <br>
                                    Saturday<br>
                                    10:00 AM - 4:00 PM
                                </p>
                            </div>
                        </div>
                    </div>

                    <div class="card">
                        <div class="card-header">
                            <h2 class="card-title">Send Us a Message</h2>
                            <p class="card-description">Fill out the form below and we'll get back to you as soon as possible.</p>
                        </div>
                        <div class="card-content">
                            <form id="contactForm" class="space-y-4" onsubmit="handleContactSubmit(event)">
                                <div class="input-group">
                                    <label for="name">Name</label>
                                    <input type="text" id="name" required>
                                </div>
                                <div class="input-group">
                                    <label for="email">Email</label>
                                    <input type="email" id="email" required>
                                </div>
                                <div class="input-group">
                                    <label for="subject">Subject</label>
                                    <input type="text" id="subject" required>
                                </div>
                                <div class="input-group">
                                    <label for="message">Message</label>
                                    <textarea id="message" rows="5" required></textarea>
                                </div>
                                <button type="submit" class="btn btn-primary w-full">Send Message</button>
                            </form>
                        </div>
                    </div>
                </div>

                ${FooterComponent.render()}
            </div>
        `;
    }
};

function handleContactSubmit(event) {
    event.preventDefault();
    alert('Thank you for your message! We will get back to you soon.');
    document.getElementById('contactForm').reset();
}
