// Dentist Dashboard Page
const DentistDashboardPage = {
    render: () => {
        const user = AuthService.getCurrentUser();
        const appointments = AppointmentService.getByDentistId(user.id);
        const pendingAppointments = appointments.filter(apt => apt.status === 'pending');
        const approvedAppointments = appointments.filter(apt => apt.status === 'approved');
        const rejectedAppointments = appointments.filter(apt => apt.status === 'rejected');
        
        const app = document.getElementById('app');
        app.innerHTML = `
            <div class="min-h-screen">
                ${HeaderComponent.renderDentist()}
                
                <div class="container max-w-6xl px-4 py-8">
                    <!-- Welcome Section -->
                    <div class="mb-8">
                        <h1 class="text-3xl mb-2">Welcome, ${user.name}!</h1>
                        <p class="text-muted">
                            Manage your appointments and patient requests
                        </p>
                    </div>

                    <!-- Stats Cards -->
                    <div class="grid md:grid-cols-3 gap-6 mb-8">
                        <div class="card">
                            <div class="stat-card pt-6">
                                <div>
                                    <p class="text-sm text-muted mb-1">Pending Requests</p>
                                    <p class="text-3xl">${pendingAppointments.length}</p>
                                </div>
                                <div class="icon-circle" style="background: rgba(234, 179, 8, 0.1);">
                                    <div style="color: #eab308;">${Icons.clock}</div>
                                </div>
                            </div>
                        </div>

                        <div class="card">
                            <div class="stat-card pt-6">
                                <div>
                                    <p class="text-sm text-muted mb-1">Approved</p>
                                    <p class="text-3xl">${approvedAppointments.length}</p>
                                </div>
                                <div class="icon-circle" style="background: rgba(34, 197, 94, 0.1);">
                                    <div style="color: #22c55e;">${Icons.checkCircle}</div>
                                </div>
                            </div>
                        </div>

                        <div class="card">
                            <div class="stat-card pt-6">
                                <div>
                                    <p class="text-sm text-muted mb-1">Total Appointments</p>
                                    <p class="text-3xl">${appointments.length}</p>
                                </div>
                                <div class="icon-circle" style="background: rgba(107, 127, 94, 0.1);">
                                    <div style="color: var(--primary);">${Icons.calendar}</div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Quick Actions -->
                    <div class="card mb-8">
                        <div class="card-header">
                            <h2 class="card-title">Quick Actions</h2>
                            <p class="card-description">Manage your appointments and profile</p>
                        </div>
                        <div class="card-content flex gap-4">
                            <a href="/dentist/appointments" data-link>
                                <button class="btn btn-primary">View All Appointments</button>
                            </a>
                            <a href="/dentist/profile" data-link>
                                <button class="btn btn-outline">Edit Profile</button>
                            </a>
                        </div>
                    </div>

                    <!-- Pending Requests -->
                    ${pendingAppointments.length > 0 ? `
                        <div class="card">
                            <div class="card-header">
                                <h2 class="card-title">Pending Appointment Requests</h2>
                                <p class="card-description">Review and respond to patient requests</p>
                            </div>
                            <div class="card-content">
                                <div class="space-y-4">
                                    ${pendingAppointments.map(appointment => `
                                        <div class="card" style="background: var(--background);">
                                            <div class="card-content p-4">
                                                <div class="flex items-start justify-between mb-4">
                                                    <div>
                                                        <h3 class="mb-1">${appointment.patientName}</h3>
                                                        <p class="text-sm text-muted">${appointment.email}</p>
                                                    </div>
                                                    <span class="badge badge-pending">Pending</span>
                                                </div>
                                                
                                                <div class="grid md:grid-cols-2 gap-4 mb-4">
                                                    <div>
                                                        <p class="text-sm text-muted mb-1">Date & Time</p>
                                                        <p>${new Date(appointment.date).toLocaleDateString()} at ${appointment.timeSlot}</p>
                                                    </div>
                                                    <div>
                                                        <p class="text-sm text-muted mb-1">Contact</p>
                                                        <p>${appointment.contactNumber}</p>
                                                    </div>
                                                    <div>
                                                        <p class="text-sm text-muted mb-1">Age / Gender</p>
                                                        <p>${appointment.age} years / ${appointment.gender}</p>
                                                    </div>
                                                    <div>
                                                        <p class="text-sm text-muted mb-1">Reason</p>
                                                        <p>${appointment.reason}</p>
                                                    </div>
                                                </div>
                                                
                                                <div class="flex gap-2">
                                                    <button class="btn btn-primary btn-sm" onclick="showApprovalModal('${appointment.id}', 'approve')">
                                                        Approve
                                                    </button>
                                                    <button class="btn btn-destructive btn-sm" onclick="showApprovalModal('${appointment.id}', 'reject')">
                                                        Reject
                                                    </button>
                                                </div>
                                            </div>
                                        </div>
                                    `).join('')}
                                </div>
                            </div>
                        </div>
                    ` : `
                        <div class="card">
                            <div class="card-content py-12 text-center">
                                <div class="icon-circle-lg mx-auto mb-4" style="background: var(--muted);">
                                    <div style="color: var(--muted-foreground);">${Icons.checkCircle}</div>
                                </div>
                                <h3 class="mb-2">No Pending Requests</h3>
                                <p class="text-muted">
                                    You're all caught up! No appointment requests waiting for review.
                                </p>
                            </div>
                        </div>
                    `}
                </div>

                ${FooterComponent.render()}
            </div>
            
            <!-- Modal Container -->
            <div id="modal-container"></div>
        `;
    }
};

function showApprovalModal(appointmentId, action) {
    const modalContainer = document.getElementById('modal-container');
    const title = action === 'approve' ? 'Approve Appointment' : 'Reject Appointment';
    const buttonClass = action === 'approve' ? 'btn-primary' : 'btn-destructive';
    const buttonText = action === 'approve' ? 'Approve' : 'Reject';
    
    modalContainer.innerHTML = `
        <div class="modal-overlay" onclick="closeModal()">
            <div class="modal" onclick="event.stopPropagation()">
                <div class="modal-header">
                    <h3>${title}</h3>
                </div>
                <div class="modal-body">
                    <div class="input-group">
                        <label for="dentist-notes">Add a note for the patient (optional)</label>
                        <textarea id="dentist-notes" rows="4" placeholder="Add any notes or instructions..."></textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <button class="btn btn-outline" onclick="closeModal()">Cancel</button>
                    <button class="btn ${buttonClass}" onclick="handleApproval('${appointmentId}', '${action}')">
                        ${buttonText}
                    </button>
                </div>
            </div>
        </div>
    `;
}

function closeModal() {
    document.getElementById('modal-container').innerHTML = '';
}

function handleApproval(appointmentId, action) {
    const notes = document.getElementById('dentist-notes').value;
    const status = action === 'approve' ? 'approved' : 'rejected';
    
    AppointmentService.updateStatus(appointmentId, status, notes);
    closeModal();
    alert(`Appointment ${status} successfully!`);
    DentistDashboardPage.render();
}
