// Manage Appointments Page
const ManageAppointmentsPage = {
    render: () => {
        const user = AuthService.getCurrentUser();
        const allAppointments = AppointmentService.getByDentistId(user.id);
        
        const app = document.getElementById('app');
        app.innerHTML = `
            <div class="min-h-screen">
                ${HeaderComponent.renderDentist()}
                
                <div class="container max-w-6xl px-4 py-8">
                    <div class="mb-8">
                        <h1 class="text-3xl mb-2">Manage Appointments</h1>
                        <p class="text-muted">
                            View and manage all your appointment requests
                        </p>
                    </div>

                    <!-- Filter -->
                    <div class="card mb-8">
                        <div class="card-content">
                            <h3 class="mb-4">Filter by Status</h3>
                            <div class="filter-buttons">
                                <button class="filter-btn active" onclick="filterAppointmentsByStatus('all')">
                                    All (${allAppointments.length})
                                </button>
                                <button class="filter-btn" onclick="filterAppointmentsByStatus('pending')">
                                    Pending (${allAppointments.filter(a => a.status === 'pending').length})
                                </button>
                                <button class="filter-btn" onclick="filterAppointmentsByStatus('approved')">
                                    Approved (${allAppointments.filter(a => a.status === 'approved').length})
                                </button>
                                <button class="filter-btn" onclick="filterAppointmentsByStatus('rejected')">
                                    Rejected (${allAppointments.filter(a => a.status === 'rejected').length})
                                </button>
                            </div>
                        </div>
                    </div>

                    <!-- Appointments List -->
                    ${allAppointments.length === 0 ? `
                        <div class="card">
                            <div class="card-content py-12 text-center">
                                <div class="icon-circle-lg mx-auto mb-4" style="background: var(--muted);">
                                    <div style="color: var(--muted-foreground);">${Icons.calendar}</div>
                                </div>
                                <h3 class="mb-2">No Appointments Yet</h3>
                                <p class="text-muted">
                                    You haven't received any appointment requests yet
                                </p>
                            </div>
                        </div>
                    ` : `
                        <div class="space-y-4" id="appointments-list">
                            ${allAppointments.map(appointment => {
                                const statusConfig = {
                                    pending: {
                                        badge: 'badge-pending',
                                        icon: Icons.clock,
                                        iconBg: 'rgba(234, 179, 8, 0.1)',
                                        iconColor: '#eab308'
                                    },
                                    approved: {
                                        badge: 'badge-approved',
                                        icon: Icons.checkCircle,
                                        iconBg: 'rgba(34, 197, 94, 0.1)',
                                        iconColor: '#22c55e'
                                    },
                                    rejected: {
                                        badge: 'badge-rejected',
                                        icon: Icons.xCircle,
                                        iconBg: 'rgba(239, 68, 68, 0.1)',
                                        iconColor: '#ef4444'
                                    }
                                };
                                
                                const config = statusConfig[appointment.status];
                                
                                return `
                                    <div class="card appointment-card" data-status="${appointment.status}">
                                        <div class="card-content p-6">
                                            <div class="flex items-start justify-between mb-4">
                                                <div class="flex gap-4">
                                                    <div class="icon-circle" style="background: ${config.iconBg};">
                                                        <div style="color: ${config.iconColor};">${config.icon}</div>
                                                    </div>
                                                    <div>
                                                        <h3 class="mb-1">${appointment.patientName}</h3>
                                                        <p class="text-sm text-muted">${appointment.email}</p>
                                                        <p class="text-sm text-muted">${appointment.contactNumber}</p>
                                                    </div>
                                                </div>
                                                <span class="badge ${config.badge}">${appointment.status.charAt(0).toUpperCase() + appointment.status.slice(1)}</span>
                                            </div>
                                            
                                            <div class="grid md:grid-cols-2 gap-4 mb-4">
                                                <div>
                                                    <p class="text-sm text-muted mb-1">Date & Time</p>
                                                    <p>${new Date(appointment.date).toLocaleDateString()} at ${appointment.timeSlot}</p>
                                                </div>
                                                <div>
                                                    <p class="text-sm text-muted mb-1">Age / Gender</p>
                                                    <p>${appointment.age} years / ${appointment.gender}</p>
                                                </div>
                                            </div>
                                            
                                            <div class="mb-4">
                                                <p class="text-sm text-muted mb-1">Reason for Visit</p>
                                                <p>${appointment.reason}</p>
                                            </div>
                                            
                                            ${appointment.dentistNotes ? `
                                                <div class="p-4 mb-4" style="background: var(--secondary); border-radius: calc(var(--radius) - 2px);">
                                                    <p class="text-sm text-muted mb-1">Your Note:</p>
                                                    <p>${appointment.dentistNotes}</p>
                                                </div>
                                            ` : ''}
                                            
                                            <div class="flex gap-2">
                                                ${appointment.status === 'pending' ? `
                                                    <button class="btn btn-primary btn-sm" onclick="showApprovalModal('${appointment.id}', 'approve')">
                                                        Approve
                                                    </button>
                                                    <button class="btn btn-destructive btn-sm" onclick="showApprovalModal('${appointment.id}', 'reject')">
                                                        Reject
                                                    </button>
                                                ` : ''}
                                                <button class="btn btn-outline btn-sm" onclick="deleteAppointment('${appointment.id}')">
                                                    Delete
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                `;
                            }).join('')}
                        </div>
                    `}
                </div>

                ${FooterComponent.render()}
            </div>
            
            <!-- Modal Container -->
            <div id="modal-container"></div>
        `;
    }
};

function filterAppointmentsByStatus(status) {
    // Update active filter button
    const buttons = document.querySelectorAll('.filter-btn');
    buttons.forEach(btn => btn.classList.remove('active'));
    event.target.classList.add('active');
    
    // Filter appointment cards
    const cards = document.querySelectorAll('.appointment-card');
    cards.forEach(card => {
        if (status === 'all' || card.dataset.status === status) {
            card.style.display = 'block';
        } else {
            card.style.display = 'none';
        }
    });
}

function deleteAppointment(appointmentId) {
    if (confirm('Are you sure you want to delete this appointment?')) {
        AppointmentService.delete(appointmentId);
        alert('Appointment deleted successfully.');
        ManageAppointmentsPage.render();
    }
}
