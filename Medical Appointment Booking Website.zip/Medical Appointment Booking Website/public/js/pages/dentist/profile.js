// Dentist Profile Page
const DentistProfilePage = {
    render: () => {
        const user = AuthService.getCurrentUser();
        const dentist = DentistService.getById(user.id);
        
        if (!dentist) {
            alert('Dentist profile not found');
            Router.navigate('/dentist/dashboard');
            return;
        }
        
        const app = document.getElementById('app');
        app.innerHTML = `
            <div class="min-h-screen">
                ${HeaderComponent.renderDentist()}
                
                <div class="container max-w-4xl px-4 py-8">
                    <div class="mb-8">
                        <h1 class="text-3xl mb-2">Edit Profile</h1>
                        <p class="text-muted">
                            Update your professional information and availability
                        </p>
                    </div>

                    <div class="card mb-8">
                        <div class="card-header">
                            <h2 class="card-title">Professional Information</h2>
                        </div>
                        <div class="card-content">
                            <form id="profile-form" class="space-y-4" onsubmit="handleProfileUpdate(event)">
                                <div class="input-group">
                                    <label for="name">Full Name *</label>
                                    <input type="text" id="name" value="${dentist.name}" required>
                                </div>

                                <div class="input-group">
                                    <label for="specialization">Specialization *</label>
                                    <select id="specialization" required>
                                        <option value="General Dentistry" ${dentist.specialization === 'General Dentistry' ? 'selected' : ''}>General Dentistry</option>
                                        <option value="Orthodontics" ${dentist.specialization === 'Orthodontics' ? 'selected' : ''}>Orthodontics</option>
                                        <option value="Oral Surgery" ${dentist.specialization === 'Oral Surgery' ? 'selected' : ''}>Oral Surgery</option>
                                        <option value="Pediatric Dentistry" ${dentist.specialization === 'Pediatric Dentistry' ? 'selected' : ''}>Pediatric Dentistry</option>
                                        <option value="Periodontics" ${dentist.specialization === 'Periodontics' ? 'selected' : ''}>Periodontics</option>
                                        <option value="Endodontics" ${dentist.specialization === 'Endodontics' ? 'selected' : ''}>Endodontics</option>
                                        <option value="Prosthodontics" ${dentist.specialization === 'Prosthodontics' ? 'selected' : ''}>Prosthodontics</option>
                                        <option value="Cosmetic Dentistry" ${dentist.specialization === 'Cosmetic Dentistry' ? 'selected' : ''}>Cosmetic Dentistry</option>
                                    </select>
                                </div>

                                <div class="input-group">
                                    <label for="credentials">Credentials *</label>
                                    <input type="text" id="credentials" value="${dentist.credentials}" required placeholder="e.g., DDS, DMD, Board Certified">
                                </div>

                                <div class="input-group">
                                    <label for="description">Professional Description *</label>
                                    <textarea id="description" rows="4" required>${dentist.description}</textarea>
                                </div>

                                <button type="submit" class="btn btn-primary">
                                    Save Changes
                                </button>
                            </form>
                        </div>
                    </div>

                    <div class="card">
                        <div class="card-header">
                            <h2 class="card-title">Availability Schedule</h2>
                            <p class="card-description">Manage your available days and time slots</p>
                        </div>
                        <div class="card-content">
                            <div id="availability-section">
                                ${dentist.availability.map((day, index) => `
                                    <div class="card mb-4" style="background: var(--background);">
                                        <div class="card-content p-4">
                                            <div class="flex items-center justify-between mb-4">
                                                <h4>${day.day}</h4>
                                                <button class="btn btn-outline btn-sm" onclick="removeAvailabilityDay(${index})">
                                                    Remove
                                                </button>
                                            </div>
                                            <div class="flex gap-2 flex-wrap mb-4">
                                                ${day.slots.map((slot, slotIndex) => `
                                                    <span class="badge" style="background: var(--accent); color: white; padding: 0.5rem 0.75rem; display: flex; align-items: center; gap: 0.5rem;">
                                                        ${slot}
                                                        <button onclick="removeTimeSlot(${index}, ${slotIndex})" style="background: none; border: none; cursor: pointer; color: white; padding: 0;">
                                                            ×
                                                        </button>
                                                    </span>
                                                `).join('')}
                                            </div>
                                            <div class="flex gap-2">
                                                <input type="time" id="new-slot-${index}" class="w-full" style="flex: 1;">
                                                <button class="btn btn-sm btn-primary" onclick="addTimeSlot(${index})">
                                                    Add Slot
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                `).join('')}
                            </div>
                            
                            <div class="mt-4">
                                <h4 class="mb-4">Add New Availability Day</h4>
                                <div class="flex gap-2">
                                    <select id="new-day" style="flex: 1;">
                                        <option value="">Select a day</option>
                                        <option value="Monday">Monday</option>
                                        <option value="Tuesday">Tuesday</option>
                                        <option value="Wednesday">Wednesday</option>
                                        <option value="Thursday">Thursday</option>
                                        <option value="Friday">Friday</option>
                                        <option value="Saturday">Saturday</option>
                                        <option value="Sunday">Sunday</option>
                                    </select>
                                    <button class="btn btn-primary" onclick="addAvailabilityDay()">
                                        Add Day
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                ${FooterComponent.render()}
            </div>
        `;
    }
};

function handleProfileUpdate(event) {
    event.preventDefault();
    
    const user = AuthService.getCurrentUser();
    const updates = {
        name: document.getElementById('name').value,
        specialization: document.getElementById('specialization').value,
        credentials: document.getElementById('credentials').value,
        description: document.getElementById('description').value
    };
    
    DentistService.updateProfile(user.id, updates);
    alert('Profile updated successfully!');
}

function addTimeSlot(dayIndex) {
    const user = AuthService.getCurrentUser();
    const dentist = DentistService.getById(user.id);
    const timeInput = document.getElementById(`new-slot-${dayIndex}`);
    const timeValue = timeInput.value;
    
    if (!timeValue) {
        alert('Please select a time');
        return;
    }
    
    // Convert 24h to 12h format
    const [hours, minutes] = timeValue.split(':');
    const hour = parseInt(hours);
    const ampm = hour >= 12 ? 'PM' : 'AM';
    const displayHour = hour === 0 ? 12 : hour > 12 ? hour - 12 : hour;
    const formattedTime = `${displayHour}:${minutes} ${ampm}`;
    
    dentist.availability[dayIndex].slots.push(formattedTime);
    DentistService.updateProfile(user.id, { availability: dentist.availability });
    
    timeInput.value = '';
    DentistProfilePage.render();
}

function removeTimeSlot(dayIndex, slotIndex) {
    const user = AuthService.getCurrentUser();
    const dentist = DentistService.getById(user.id);
    
    dentist.availability[dayIndex].slots.splice(slotIndex, 1);
    DentistService.updateProfile(user.id, { availability: dentist.availability });
    
    DentistProfilePage.render();
}

function addAvailabilityDay() {
    const user = AuthService.getCurrentUser();
    const dentist = DentistService.getById(user.id);
    const daySelect = document.getElementById('new-day');
    const newDay = daySelect.value;
    
    if (!newDay) {
        alert('Please select a day');
        return;
    }
    
    // Check if day already exists
    if (dentist.availability.some(d => d.day === newDay)) {
        alert('This day is already in your availability');
        return;
    }
    
    dentist.availability.push({ day: newDay, slots: [] });
    DentistService.updateProfile(user.id, { availability: dentist.availability });
    
    daySelect.value = '';
    DentistProfilePage.render();
}

function removeAvailabilityDay(dayIndex) {
    if (!confirm('Are you sure you want to remove this day from your availability?')) {
        return;
    }
    
    const user = AuthService.getCurrentUser();
    const dentist = DentistService.getById(user.id);
    
    dentist.availability.splice(dayIndex, 1);
    DentistService.updateProfile(user.id, { availability: dentist.availability });
    
    DentistProfilePage.render();
}
