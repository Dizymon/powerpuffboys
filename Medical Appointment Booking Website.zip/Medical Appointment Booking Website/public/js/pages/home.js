// Home Page
const HomePage = {
    render: () => {
        const app = document.getElementById('app');
        app.innerHTML = `
            <div class="min-h-screen">
                ${HeaderComponent.renderPublic()}
                
                <!-- Hero Section -->
                <section class="py-20 px-4">
                    <div class="container max-w-4xl text-center">
                        <h1 class="text-5xl mb-6">Book Your Dental Appointment Online</h1>
                        <p class="text-xl text-muted mb-8 mx-auto" style="max-width: 42rem;">
                            Connect with licensed dentists and manage your dental care appointments seamlessly. 
                            Professional, convenient, and trusted dental services at your fingertips.
                        </p>
                        <a href="/login" data-link>
                            <button class="btn btn-primary btn-lg">
                                Login to Book an Appointment
                            </button>
                        </a>
                    </div>
                </section>

                <!-- Features Section -->
                <section class="py-16 px-4" style="background: white;">
                    <div class="container max-w-6xl">
                        <h2 class="text-3xl text-center mb-12">How It Works</h2>
                        <div class="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
                            <div class="card" style="border-width: 2px; text-align: center;">
                                <div class="card-content p-6">
                                    <div class="icon-circle mx-auto mb-4" style="background: rgba(107, 127, 94, 0.2);">
                                        <div style="color: var(--primary);">${Icons.users}</div>
                                    </div>
                                    <h3 class="mb-2">Choose Your Dentist</h3>
                                    <p class="text-sm text-muted">
                                        Browse profiles of licensed dental professionals with various specializations
                                    </p>
                                </div>
                            </div>

                            <div class="card" style="border-width: 2px; text-align: center;">
                                <div class="card-content p-6">
                                    <div class="icon-circle mx-auto mb-4" style="background: rgba(107, 127, 94, 0.2);">
                                        <div style="color: var(--primary);">${Icons.calendar}</div>
                                    </div>
                                    <h3 class="mb-2">Select Time Slot</h3>
                                    <p class="text-sm text-muted">
                                        View available days and times that fit your schedule
                                    </p>
                                </div>
                            </div>

                            <div class="card" style="border-width: 2px; text-align: center;">
                                <div class="card-content p-6">
                                    <div class="icon-circle mx-auto mb-4" style="background: rgba(107, 127, 94, 0.2);">
                                        <div style="color: var(--primary);">${Icons.shield}</div>
                                    </div>
                                    <h3 class="mb-2">Submit Request</h3>
                                    <p class="text-sm text-muted">
                                        Fill in your details and submit your appointment request for approval
                                    </p>
                                </div>
                            </div>

                            <div class="card" style="border-width: 2px; text-align: center;">
                                <div class="card-content p-6">
                                    <div class="icon-circle mx-auto mb-4" style="background: rgba(107, 127, 94, 0.2);">
                                        <div style="color: var(--primary);">${Icons.clock}</div>
                                    </div>
                                    <h3 class="mb-2">Track Status</h3>
                                    <p class="text-sm text-muted">
                                        Monitor your appointment status and receive updates from your dentist
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>

                <!-- Benefits Section -->
                <section class="py-16 px-4">
                    <div class="container max-w-4xl">
                        <h2 class="text-3xl text-center mb-12">Why Choose DentalCare Connect?</h2>
                        <div class="grid md:grid-cols-3 gap-8">
                            <div class="text-center">
                                <div class="text-4xl mb-4">🦷</div>
                                <h3 class="mb-2">Licensed Professionals</h3>
                                <p class="text-sm text-muted">
                                    All dentists are licensed and credentialed specialists
                                </p>
                            </div>
                            <div class="text-center">
                                <div class="text-4xl mb-4">⏰</div>
                                <h3 class="mb-2">Flexible Scheduling</h3>
                                <p class="text-sm text-muted">
                                    Book appointments that work with your busy schedule
                                </p>
                            </div>
                            <div class="text-center">
                                <div class="text-4xl mb-4">✨</div>
                                <h3 class="mb-2">Modern & Simple</h3>
                                <p class="text-sm text-muted">
                                    Easy-to-use platform for hassle-free appointment management
                                </p>
                            </div>
                        </div>
                    </div>
                </section>

                ${FooterComponent.render()}
            </div>
        `;
    }
};
