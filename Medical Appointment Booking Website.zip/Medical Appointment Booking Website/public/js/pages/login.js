// Login Page
const LoginPage = {
    render: () => {
        const app = document.getElementById('app');
        app.innerHTML = `
            <div class="min-h-screen flex flex-col">
                ${HeaderComponent.renderPublic()}
                
                <div class="flex-1 flex items-center justify-center px-4 py-12">
                    <div class="card w-full max-w-md">
                        <div class="card-header text-center">
                            <h2 class="card-title">Welcome Back</h2>
                            <p class="card-description">
                                Log in to manage your dental appointments
                            </p>
                        </div>
                        <div class="card-content">
                            <div class="tabs">
                                <div class="tabs-list">
                                    <button class="tab-trigger active" onclick="switchTab('patient')">Patient</button>
                                    <button class="tab-trigger" onclick="switchTab('dentist')">Dentist</button>
                                </div>
                                
                                <div class="tab-content active" id="patient-tab">
                                    <form class="space-y-4" onsubmit="handleLogin(event, 'patient')">
                                        <div class="input-group">
                                            <label for="patient-email">Email</label>
                                            <input type="email" id="patient-email" placeholder="patient@example.com" required>
                                        </div>
                                        <div class="input-group">
                                            <label for="patient-password">Password</label>
                                            <input type="password" id="patient-password" placeholder="••••••••" required>
                                        </div>
                                        <button type="submit" class="btn btn-primary w-full" id="patient-submit-btn">
                                            Login as Patient
                                        </button>
                                        <p class="text-sm text-muted text-center mt-4">
                                            Demo: Use any email/password to login
                                        </p>
                                    </form>
                                </div>

                                <div class="tab-content" id="dentist-tab">
                                    <form class="space-y-4" onsubmit="handleLogin(event, 'dentist')">
                                        <div class="input-group">
                                            <label for="dentist-email">Email</label>
                                            <input type="email" id="dentist-email" placeholder="dentist@example.com" required>
                                        </div>
                                        <div class="input-group">
                                            <label for="dentist-password">Password</label>
                                            <input type="password" id="dentist-password" placeholder="••••••••" required>
                                        </div>
                                        <button type="submit" class="btn btn-primary w-full" id="dentist-submit-btn">
                                            Login as Dentist
                                        </button>
                                        <p class="text-sm text-muted text-center mt-4">
                                            Demo: Use any email/password to login
                                        </p>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        `;
    }
};

function switchTab(tab) {
    // Update tab triggers
    const triggers = document.querySelectorAll('.tab-trigger');
    triggers.forEach(t => t.classList.remove('active'));
    event.target.classList.add('active');
    
    // Update tab content
    const contents = document.querySelectorAll('.tab-content');
    contents.forEach(c => c.classList.remove('active'));
    document.getElementById(`${tab}-tab`).classList.add('active');
}

async function handleLogin(event, role) {
    event.preventDefault();
    
    const emailInput = document.getElementById(`${role}-email`);
    const passwordInput = document.getElementById(`${role}-password`);
    const submitBtn = document.getElementById(`${role}-submit-btn`);
    
    // Disable button
    submitBtn.disabled = true;
    submitBtn.textContent = 'Logging in...';
    
    try {
        await AuthService.login(emailInput.value, passwordInput.value, role);
        
        // Navigate based on role
        if (role === 'patient') {
            Router.navigate('/patient/dashboard');
        } else {
            Router.navigate('/dentist/dashboard');
        }
    } catch (error) {
        console.error('Login failed:', error);
        alert('Login failed. Please try again.');
    } finally {
        submitBtn.disabled = false;
        submitBtn.textContent = role === 'patient' ? 'Login as Patient' : 'Login as Dentist';
    }
}
