// Patient Appointments Page (Browse Dentists)
const PatientAppointmentsPage = {
    render: () => {
        const dentists = DentistService.getAll();
        const specializations = [...new Set(dentists.map(d => d.specialization))];
        
        const app = document.getElementById('app');
        app.innerHTML = `
            <div class="min-h-screen">
                ${HeaderComponent.renderPatient()}
                
                <div class="container max-w-6xl px-4 py-8">
                    <div class="mb-8">
                        <h1 class="text-3xl mb-2">Browse Dentists</h1>
                        <p class="text-muted">
                            Find and book appointments with licensed dental professionals
                        </p>
                    </div>

                    <!-- Filter by Specialization -->
                    <div class="card mb-8">
                        <div class="card-content">
                            <h3 class="mb-4">Filter by Specialization</h3>
                            <div class="filter-buttons">
                                <button class="filter-btn active" onclick="filterDentists('all')">
                                    All Specializations
                                </button>
                                ${specializations.map(spec => `
                                    <button class="filter-btn" onclick="filterDentists('${spec}')">
                                        ${spec}
                                    </button>
                                `).join('')}
                            </div>
                        </div>
                    </div>

                    <!-- Dentists Grid -->
                    <div class="grid md:grid-cols-2 gap-6" id="dentists-grid">
                        ${dentists.map(dentist => `
                            <div class="dentist-card" data-specialization="${dentist.specialization}" onclick="Router.navigate('/patient/dentist/${dentist.id}')">
                                <div class="flex items-start gap-4 mb-4">
                                    <div class="icon-circle-lg" style="background: var(--primary); color: white;">
                                        ${Icons.user}
                                    </div>
                                    <div style="flex: 1;">
                                        <h3 class="mb-1">${dentist.name}</h3>
                                        <p class="text-sm text-muted mb-2">${dentist.specialization}</p>
                                        <p class="text-sm text-muted">${dentist.credentials}</p>
                                    </div>
                                </div>
                                <p class="text-sm text-muted mb-4">
                                    ${dentist.description}
                                </p>
                                <div class="flex justify-between items-center">
                                    <span class="text-sm text-muted">
                                        Available ${dentist.availability.length} days/week
                                    </span>
                                    <button class="btn btn-primary btn-sm" onclick="event.stopPropagation(); Router.navigate('/patient/dentist/${dentist.id}')">
                                        View Profile
                                    </button>
                                </div>
                            </div>
                        `).join('')}
                    </div>
                </div>

                ${FooterComponent.render()}
            </div>
        `;
    }
};

function filterDentists(specialization) {
    // Update active filter button
    const buttons = document.querySelectorAll('.filter-btn');
    buttons.forEach(btn => btn.classList.remove('active'));
    event.target.classList.add('active');
    
    // Filter dentist cards
    const cards = document.querySelectorAll('.dentist-card');
    cards.forEach(card => {
        if (specialization === 'all' || card.dataset.specialization === specialization) {
            card.style.display = 'block';
        } else {
            card.style.display = 'none';
        }
    });
}
