// Approval Status Page
const ApprovalStatusPage = {
    render: () => {
        const user = AuthService.getCurrentUser();
        const appointments = AppointmentService.getByPatientId(user.id);
        
        const app = document.getElementById('app');
        app.innerHTML = `
            <div class="min-h-screen">
                ${HeaderComponent.renderPatient()}
                
                <div class="container max-w-6xl px-4 py-8">
                    <div class="mb-8">
                        <h1 class="text-3xl mb-2">Appointment Status</h1>
                        <p class="text-muted">
                            Track the status of your appointment requests
                        </p>
                    </div>

                    ${appointments.length === 0 ? `
                        <div class="card">
                            <div class="card-content py-12 text-center">
                                <div class="icon-circle-lg mx-auto mb-4" style="background: var(--muted);">
                                    <div style="color: var(--muted-foreground);">${Icons.calendar}</div>
                                </div>
                                <h3 class="mb-2">No Appointments Yet</h3>
                                <p class="text-muted mb-6">
                                    You haven't booked any appointments yet
                                </p>
                                <a href="/patient/appointments" data-link>
                                    <button class="btn btn-primary">Browse Dentists</button>
                                </a>
                            </div>
                        </div>
                    ` : `
                        <div class="space-y-4">
                            ${appointments.map(appointment => {
                                const dentist = DentistService.getById(appointment.dentistId);
                                const statusConfig = {
                                    pending: {
                                        badge: 'badge-pending',
                                        icon: Icons.clock,
                                        iconBg: 'rgba(234, 179, 8, 0.1)',
                                        iconColor: '#eab308',
                                        text: 'Pending'
                                    },
                                    approved: {
                                        badge: 'badge-approved',
                                        icon: Icons.checkCircle,
                                        iconBg: 'rgba(34, 197, 94, 0.1)',
                                        iconColor: '#22c55e',
                                        text: 'Approved'
                                    },
                                    rejected: {
                                        badge: 'badge-rejected',
                                        icon: Icons.xCircle,
                                        iconBg: 'rgba(239, 68, 68, 0.1)',
                                        iconColor: '#ef4444',
                                        text: 'Rejected'
                                    }
                                };
                                
                                const config = statusConfig[appointment.status];
                                
                                return `
                                    <div class="card">
                                        <div class="card-content p-6">
                                            <div class="flex items-start justify-between mb-4">
                                                <div class="flex gap-4">
                                                    <div class="icon-circle" style="background: ${config.iconBg};">
                                                        <div style="color: ${config.iconColor};">${config.icon}</div>
                                                    </div>
                                                    <div>
                                                        <h3 class="mb-1">${dentist?.name || 'Unknown'}</h3>
                                                        <p class="text-sm text-muted">${dentist?.specialization || ''}</p>
                                                    </div>
                                                </div>
                                                <span class="badge ${config.badge}">${config.text}</span>
                                            </div>
                                            
                                            <div class="grid md:grid-cols-2 gap-4 mb-4">
                                                <div>
                                                    <p class="text-sm text-muted mb-1">Date & Time</p>
                                                    <p>${new Date(appointment.date).toLocaleDateString()} at ${appointment.timeSlot}</p>
                                                </div>
                                                <div>
                                                    <p class="text-sm text-muted mb-1">Reason</p>
                                                    <p>${appointment.reason}</p>
                                                </div>
                                            </div>
                                            
                                            ${appointment.dentistNotes ? `
                                                <div class="p-4 mt-4" style="background: var(--secondary); border-radius: calc(var(--radius) - 2px);">
                                                    <p class="text-sm text-muted mb-1">Dentist's Note:</p>
                                                    <p>${appointment.dentistNotes}</p>
                                                </div>
                                            ` : ''}
                                            
                                            ${appointment.status === 'pending' ? `
                                                <div class="mt-4">
                                                    <button class="btn btn-outline btn-sm" onclick="cancelAppointment('${appointment.id}')">
                                                        Cancel Request
                                                    </button>
                                                </div>
                                            ` : ''}
                                        </div>
                                    </div>
                                `;
                            }).join('')}
                        </div>
                    `}
                </div>

                ${FooterComponent.render()}
            </div>
        `;
    }
};

function cancelAppointment(appointmentId) {
    if (confirm('Are you sure you want to cancel this appointment request?')) {
        AppointmentService.delete(appointmentId);
        alert('Appointment request cancelled successfully.');
        ApprovalStatusPage.render();
    }
}
