// Patient Dashboard Page
const PatientDashboardPage = {
    render: () => {
        const user = AuthService.getCurrentUser();
        const appointments = AppointmentService.getByPatientId(user.id);
        const upcomingAppointments = appointments.filter(apt => apt.status === 'approved');
        const pendingAppointments = appointments.filter(apt => apt.status === 'pending');
        
        const app = document.getElementById('app');
        app.innerHTML = `
            <div class="min-h-screen">
                ${HeaderComponent.renderPatient()}
                
                <div class="container max-w-6xl px-4 py-8">
                    <!-- Welcome Section -->
                    <div class="mb-8">
                        <h1 class="text-3xl mb-2">Welcome, ${user.name}!</h1>
                        <p class="text-muted">
                            Manage your dental appointments and track their status
                        </p>
                    </div>

                    <!-- Stats Cards -->
                    <div class="grid md:grid-cols-3 gap-6 mb-8">
                        <div class="card">
                            <div class="stat-card pt-6">
                                <div>
                                    <p class="text-sm text-muted mb-1">Total Appointments</p>
                                    <p class="text-3xl">${appointments.length}</p>
                                </div>
                                <div class="icon-circle" style="background: rgba(107, 127, 94, 0.1);">
                                    <div style="color: var(--primary);">${Icons.calendar}</div>
                                </div>
                            </div>
                        </div>

                        <div class="card">
                            <div class="stat-card pt-6">
                                <div>
                                    <p class="text-sm text-muted mb-1">Pending Approval</p>
                                    <p class="text-3xl">${pendingAppointments.length}</p>
                                </div>
                                <div class="icon-circle" style="background: rgba(234, 179, 8, 0.1);">
                                    <div style="color: #eab308;">${Icons.clock}</div>
                                </div>
                            </div>
                        </div>

                        <div class="card">
                            <div class="stat-card pt-6">
                                <div>
                                    <p class="text-sm text-muted mb-1">Approved</p>
                                    <p class="text-3xl">${upcomingAppointments.length}</p>
                                </div>
                                <div class="icon-circle" style="background: rgba(34, 197, 94, 0.1);">
                                    <div style="color: #22c55e;">${Icons.checkCircle}</div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Quick Actions -->
                    <div class="card mb-8">
                        <div class="card-header">
                            <h2 class="card-title">Quick Actions</h2>
                            <p class="card-description">Get started with booking your next dental appointment</p>
                        </div>
                        <div class="card-content flex gap-4">
                            <a href="/patient/appointments" data-link>
                                <button class="btn btn-primary">Book New Appointment</button>
                            </a>
                            ${appointments.length > 0 ? `
                                <a href="/patient/approval-status" data-link>
                                    <button class="btn btn-outline">View Appointment Status</button>
                                </a>
                            ` : ''}
                        </div>
                    </div>

                    <!-- Upcoming Appointments -->
                    ${upcomingAppointments.length > 0 ? `
                        <div class="card">
                            <div class="card-header">
                                <h2 class="card-title">Upcoming Appointments</h2>
                                <p class="card-description">Your confirmed dental appointments</p>
                            </div>
                            <div class="card-content">
                                <div class="space-y-4">
                                    ${upcomingAppointments.map(appointment => {
                                        const dentist = DentistService.getById(appointment.dentistId);
                                        return `
                                            <div class="appointment-item">
                                                <div class="appointment-info">
                                                    <div class="icon-circle" style="background: rgba(34, 197, 94, 0.1);">
                                                        <div style="color: #22c55e;">${Icons.checkCircle}</div>
                                                    </div>
                                                    <div>
                                                        <h4 class="mb-1">${dentist?.name || 'Unknown'}</h4>
                                                        <p class="text-sm text-muted">${dentist?.specialization || ''}</p>
                                                        <div class="flex gap-4 mt-2 text-sm text-muted">
                                                            <span class="flex items-center gap-1">
                                                                ${Icons.calendar}
                                                                ${new Date(appointment.date).toLocaleDateString()}
                                                            </span>
                                                            <span class="flex items-center gap-1">
                                                                ${Icons.clock}
                                                                ${appointment.timeSlot}
                                                            </span>
                                                        </div>
                                                    </div>
                                                </div>
                                                <span class="badge badge-approved">Approved</span>
                                            </div>
                                        `;
                                    }).join('')}
                                </div>
                            </div>
                        </div>
                    ` : ''}

                    <!-- No Appointments Message -->
                    ${appointments.length === 0 ? `
                        <div class="card">
                            <div class="card-content py-12 text-center">
                                <div class="icon-circle-lg mx-auto mb-4" style="background: var(--muted);">
                                    <div style="color: var(--muted-foreground);">${Icons.calendar}</div>
                                </div>
                                <h3 class="mb-2">No Appointments Yet</h3>
                                <p class="text-muted mb-6">
                                    Start by booking your first dental appointment
                                </p>
                                <a href="/patient/appointments" data-link>
                                    <button class="btn btn-primary">Browse Dentists</button>
                                </a>
                            </div>
                        </div>
                    ` : ''}
                </div>

                ${FooterComponent.render()}
            </div>
        `;
    }
};
