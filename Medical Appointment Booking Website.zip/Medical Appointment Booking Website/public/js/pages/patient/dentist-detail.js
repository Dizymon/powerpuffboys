// Patient Dentist Detail Page
const PatientDentistDetailPage = {
    render: (params) => {
        const dentist = DentistService.getById(params.dentistId);
        
        if (!dentist) {
            Router.navigate('/patient/appointments');
            return;
        }
        
        const app = document.getElementById('app');
        app.innerHTML = `
            <div class="min-h-screen">
                ${HeaderComponent.renderPatient()}
                
                <div class="container max-w-4xl px-4 py-8">
                    <a href="/patient/appointments" data-link class="text-primary mb-4" style="display: inline-block;">
                        ← Back to Dentists
                    </a>

                    <!-- Dentist Profile -->
                    <div class="card mb-8">
                        <div class="card-content p-6">
                            <div class="flex items-start gap-6 mb-6">
                                <div class="icon-circle-lg" style="background: var(--primary); color: white; width: 5rem; height: 5rem;">
                                    ${Icons.user}
                                </div>
                                <div style="flex: 1;">
                                    <h1 class="text-3xl mb-2">${dentist.name}</h1>
                                    <p class="text-lg text-muted mb-2">${dentist.specialization}</p>
                                    <p class="text-sm text-muted">${dentist.credentials}</p>
                                </div>
                            </div>
                            <div class="mb-6">
                                <h3 class="mb-2">About</h3>
                                <p class="text-muted">${dentist.description}</p>
                            </div>
                        </div>
                    </div>

                    <!-- Availability -->
                    <div class="card mb-8">
                        <div class="card-header">
                            <h2 class="card-title">Availability Schedule</h2>
                            <p class="card-description">Available time slots for appointments</p>
                        </div>
                        <div class="card-content">
                            <div class="space-y-4">
                                ${dentist.availability.map(day => `
                                    <div class="p-4" style="border: 1px solid var(--border); border-radius: var(--radius);">
                                        <h4 class="mb-2">${day.day}</h4>
                                        <div class="flex gap-2 flex-wrap">
                                            ${day.slots.map(slot => `
                                                <span class="badge" style="background: var(--accent); color: white; padding: 0.5rem 0.75rem;">
                                                    ${slot}
                                                </span>
                                            `).join('')}
                                        </div>
                                    </div>
                                `).join('')}
                            </div>
                        </div>
                    </div>

                    <!-- Book Appointment Button -->
                    <div class="text-center">
                        <a href="/patient/register-appointment/${dentist.id}" data-link>
                            <button class="btn btn-primary btn-lg">
                                Book Appointment with ${dentist.name.split(' ')[0]}
                            </button>
                        </a>
                    </div>
                </div>

                ${FooterComponent.render()}
            </div>
        `;
    }
};
