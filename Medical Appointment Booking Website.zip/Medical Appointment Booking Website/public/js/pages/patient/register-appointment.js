// Register Appointment Page
const RegisterAppointmentPage = {
    render: (params) => {
        const dentist = DentistService.getById(params.dentistId);
        
        if (!dentist) {
            Router.navigate('/patient/appointments');
            return;
        }
        
        const app = document.getElementById('app');
        app.innerHTML = `
            <div class="min-h-screen">
                ${HeaderComponent.renderPatient()}
                
                <div class="container max-w-3xl px-4 py-8">
                    <a href="/patient/dentist/${dentist.id}" data-link class="text-primary mb-4" style="display: inline-block;">
                        ← Back to ${dentist.name}'s Profile
                    </a>

                    <div class="card">
                        <div class="card-header">
                            <h2 class="card-title">Book Appointment with ${dentist.name}</h2>
                            <p class="card-description">${dentist.specialization}</p>
                        </div>
                        <div class="card-content">
                            <form id="appointment-form" class="space-y-4" onsubmit="handleAppointmentSubmit(event, '${dentist.id}')">
                                <div class="grid md:grid-cols-2 gap-4">
                                    <div class="input-group">
                                        <label for="patientName">Full Name *</label>
                                        <input type="text" id="patientName" required>
                                    </div>
                                    <div class="input-group">
                                        <label for="contactNumber">Contact Number *</label>
                                        <input type="tel" id="contactNumber" placeholder="555-0123" required>
                                    </div>
                                </div>

                                <div class="grid md:grid-cols-2 gap-4">
                                    <div class="input-group">
                                        <label for="email">Email Address *</label>
                                        <input type="email" id="email" required>
                                    </div>
                                    <div class="input-group">
                                        <label for="gender">Gender *</label>
                                        <select id="gender" required>
                                            <option value="">Select Gender</option>
                                            <option value="Male">Male</option>
                                            <option value="Female">Female</option>
                                            <option value="Other">Other</option>
                                            <option value="Prefer not to say">Prefer not to say</option>
                                        </select>
                                    </div>
                                </div>

                                <div class="input-group">
                                    <label for="age">Age *</label>
                                    <input type="number" id="age" min="1" max="120" required>
                                </div>

                                <div class="input-group">
                                    <label for="appointmentDay">Select Day *</label>
                                    <select id="appointmentDay" required onchange="updateTimeSlots('${dentist.id}')">
                                        <option value="">Select a day</option>
                                        ${dentist.availability.map(day => `
                                            <option value="${day.day}">${day.day}</option>
                                        `).join('')}
                                    </select>
                                </div>

                                <div class="input-group">
                                    <label for="timeSlot">Select Time Slot *</label>
                                    <select id="timeSlot" required disabled>
                                        <option value="">Select a day first</option>
                                    </select>
                                </div>

                                <div class="input-group">
                                    <label for="appointmentDate">Preferred Date *</label>
                                    <input type="date" id="appointmentDate" required min="${new Date().toISOString().split('T')[0]}">
                                </div>

                                <div class="input-group">
                                    <label for="reason">Reason for Visit *</label>
                                    <textarea id="reason" rows="4" placeholder="Please describe the reason for your appointment..." required></textarea>
                                </div>

                                <div class="alert alert-info">
                                    <p class="text-sm">
                                        <strong>Note:</strong> Your appointment request will be sent to the dentist for approval. 
                                        You will be notified once the dentist reviews your request.
                                    </p>
                                </div>

                                <div class="flex gap-4">
                                    <button type="submit" class="btn btn-primary" style="flex: 1;">
                                        Submit Appointment Request
                                    </button>
                                    <a href="/patient/dentist/${dentist.id}" data-link style="flex: 1;">
                                        <button type="button" class="btn btn-outline w-full">
                                            Cancel
                                        </button>
                                    </a>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>

                ${FooterComponent.render()}
            </div>
        `;
    }
};

function updateTimeSlots(dentistId) {
    const dentist = DentistService.getById(dentistId);
    const daySelect = document.getElementById('appointmentDay');
    const timeSlotSelect = document.getElementById('timeSlot');
    
    const selectedDay = daySelect.value;
    if (!selectedDay) {
        timeSlotSelect.disabled = true;
        timeSlotSelect.innerHTML = '<option value="">Select a day first</option>';
        return;
    }
    
    const dayAvailability = dentist.availability.find(d => d.day === selectedDay);
    if (dayAvailability) {
        timeSlotSelect.disabled = false;
        timeSlotSelect.innerHTML = '<option value="">Select a time slot</option>' +
            dayAvailability.slots.map(slot => `<option value="${slot}">${slot}</option>`).join('');
    }
}

function handleAppointmentSubmit(event, dentistId) {
    event.preventDefault();
    
    const user = AuthService.getCurrentUser();
    const form = document.getElementById('appointment-form');
    const formData = new FormData(form);
    
    const appointment = {
        patientId: user.id,
        dentistId: dentistId,
        patientName: document.getElementById('patientName').value,
        contactNumber: document.getElementById('contactNumber').value,
        email: document.getElementById('email').value,
        gender: document.getElementById('gender').value,
        age: document.getElementById('age').value,
        date: document.getElementById('appointmentDate').value,
        timeSlot: document.getElementById('timeSlot').value,
        reason: document.getElementById('reason').value,
        status: 'pending'
    };
    
    AppointmentService.create(appointment);
    
    alert('Appointment request submitted successfully! The dentist will review your request shortly.');
    Router.navigate('/patient/approval-status');
}
