// Authentication Service
const AuthService = {
    currentUser: null,
    
    // Check if user is authenticated
    isAuthenticated: () => {
        const user = localStorage.getItem('dentalcare_user');
        if (user) {
            AuthService.currentUser = JSON.parse(user);
            return true;
        }
        return false;
    },
    
    // Get current user
    getCurrentUser: () => {
        if (!AuthService.currentUser) {
            const user = localStorage.getItem('dentalcare_user');
            if (user) {
                AuthService.currentUser = JSON.parse(user);
            }
        }
        return AuthService.currentUser;
    },
    
    // Login
    login: (email, password, role) => {
        return new Promise((resolve) => {
            setTimeout(() => {
                const mockUser = {
                    id: role === 'patient' ? 'patient-1' : 'dentist-1',
                    name: role === 'patient' ? 'John Doe' : 'Dr. Sarah Johnson',
                    email: email,
                    role: role
                };
                
                AuthService.currentUser = mockUser;
                localStorage.setItem('dentalcare_user', JSON.stringify(mockUser));
                resolve(mockUser);
            }, 500);
        });
    },
    
    // Logout
    logout: () => {
        AuthService.currentUser = null;
        localStorage.removeItem('dentalcare_user');
    },
    
    // Check if user has required role
    hasRole: (role) => {
        const user = AuthService.getCurrentUser();
        return user && user.role === role;
    }
};
