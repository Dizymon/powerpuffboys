// Simple Router
const Router = {
    routes: {},
    currentRoute: '/',
    
    // Initialize router
    init: () => {
        // Handle browser back/forward
        window.addEventListener('popstate', () => {
            Router.loadRoute(window.location.pathname + window.location.search);
        });
        
        // Handle initial load
        const path = window.location.pathname + window.location.search;
        Router.loadRoute(path || '/');
        
        // Handle link clicks
        document.addEventListener('click', (e) => {
            if (e.target.tagName === 'A' && e.target.hasAttribute('data-link')) {
                e.preventDefault();
                Router.navigate(e.target.getAttribute('href'));
            }
        });
    },
    
    // Register a route
    register: (path, handler) => {
        Router.routes[path] = handler;
    },
    
    // Navigate to a route
    navigate: (path) => {
        window.history.pushState({}, '', path);
        Router.loadRoute(path);
    },
    
    // Load and render a route
    loadRoute: (path) => {
        // Extract path without query string
        const [pathname, queryString] = path.split('?');
        
        // Parse query parameters
        const params = {};
        if (queryString) {
            queryString.split('&').forEach(param => {
                const [key, value] = param.split('=');
                params[decodeURIComponent(key)] = decodeURIComponent(value || '');
            });
        }
        
        // Check for protected routes
        if (pathname.startsWith('/patient')) {
            if (!AuthService.isAuthenticated() || !AuthService.hasRole('patient')) {
                Router.navigate('/login');
                return;
            }
        } else if (pathname.startsWith('/dentist')) {
            if (!AuthService.isAuthenticated() || !AuthService.hasRole('dentist')) {
                Router.navigate('/login');
                return;
            }
        }
        
        // Find matching route handler
        let handler = Router.routes[pathname];
        
        // If no exact match, try pattern matching for dynamic routes
        if (!handler) {
            for (const route in Router.routes) {
                const pattern = route.replace(/:[^/]+/g, '([^/]+)');
                const regex = new RegExp(`^${pattern}$`);
                const match = pathname.match(regex);
                
                if (match) {
                    handler = Router.routes[route];
                    // Extract dynamic params
                    const keys = route.match(/:[^/]+/g) || [];
                    keys.forEach((key, i) => {
                        params[key.substring(1)] = match[i + 1];
                    });
                    break;
                }
            }
        }
        
        // Call handler or show 404
        if (handler) {
            Router.currentRoute = pathname;
            handler(params);
        } else {
            Router.navigate('/');
        }
    },
    
    // Get current route
    getCurrentRoute: () => Router.currentRoute
};
