import { Link, Outlet, useNavigate } from 'react-router';
import { useAuth } from '../../context/AuthContext';
import { Button } from '../ui/button';
import { Calendar, LogOut } from 'lucide-react';

export default function DentistLayout() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  
  const handleLogout = () => {
    logout();
    navigate('/');
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border bg-white">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="h-10 w-10 rounded-full bg-primary flex items-center justify-center">
                <Calendar className="h-6 w-6 text-white" />
              </div>
              <h1 className="text-xl">DentalCare Connect</h1>
            </div>
            <nav className="flex gap-6 items-center">
              <Link 
                to="/dentist/dashboard" 
                className="text-foreground hover:text-primary transition-colors"
              >
                Pending Registrations
              </Link>
              <Link 
                to="/dentist/appointments" 
                className="text-foreground hover:text-primary transition-colors"
              >
                Manage Appointments
              </Link>
              <Link 
                to="/dentist/profile" 
                className="text-foreground hover:text-primary transition-colors"
              >
                Profile
              </Link>
              <Button 
                variant="outline" 
                size="sm"
                onClick={handleLogout}
                className="flex items-center gap-2"
              >
                <LogOut className="h-4 w-4" />
                Logout
              </Button>
            </nav>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main>
        <Outlet />
      </main>
    </div>
  );
}
