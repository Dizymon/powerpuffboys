import { Link, Outlet, useNavigate } from 'react-router';
import { useAuth } from '../../context/AuthContext';
import { Button } from '../ui/button';
import { Activity, LogOut } from 'lucide-react';
import { appointmentService } from '../../services/mockData';
import { useState, useEffect } from 'react';

export default function PatientLayout() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const [hasAppointments, setHasAppointments] = useState(false);
  
  // Check if patient has any appointments
  useEffect(() => {
    const checkAppointments = () => {
      if (user) {
        const appointments = appointmentService.getByPatientId(user.id);
        setHasAppointments(appointments.length > 0);
      }
    };
    
    checkAppointments();
    
    // Listen for appointment updates
    const handleUpdate = () => checkAppointments();
    window.addEventListener('appointmentUpdate', handleUpdate);
    window.addEventListener('storage', handleUpdate);
    
    return () => {
      window.removeEventListener('appointmentUpdate', handleUpdate);
      window.removeEventListener('storage', handleUpdate);
    };
  }, [user]);
  
  const handleLogout = () => {
    logout();
    navigate('/');
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border bg-white">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="h-10 w-10 rounded-full bg-primary flex items-center justify-center">
                <Activity className="h-6 w-6 text-white" />
              </div>
              <h1 className="text-xl">Medical Appointment System</h1>
            </div>
            <nav className="flex gap-6 items-center">
              <Link 
                to="/patient/dashboard" 
                className="text-foreground hover:text-primary transition-colors"
              >
                Home
              </Link>
              <Link 
                to="/patient/appointments" 
                className="text-foreground hover:text-primary transition-colors"
              >
                Appointments
              </Link>
              {hasAppointments && (
                <Link 
                  to="/patient/approval-status" 
                  className="text-foreground hover:text-primary transition-colors"
                >
                  Approval Status
                </Link>
              )}
              <Button 
                variant="outline" 
                size="sm"
                onClick={handleLogout}
                className="flex items-center gap-2"
              >
                <LogOut className="h-4 w-4" />
                Logout
              </Button>
            </nav>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main>
        <Outlet />
      </main>
    </div>
  );
}