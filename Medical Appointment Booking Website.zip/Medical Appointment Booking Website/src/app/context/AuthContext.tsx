import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';

export type UserRole = 'patient' | 'doctor' | null;

interface User {
  id: string;
  name: string;
  email: string;
  role: UserRole;
}

interface AuthContextType {
  user: User | null;
  login: (email: string, password: string, role: UserRole) => Promise<void>;
  logout: () => void;
  isAuthenticated: boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(() => {
    // Load user from localStorage on initial render
    const savedUser = localStorage.getItem('medicalAppUser');
    return savedUser ? JSON.parse(savedUser) : null;
  });

  // Save user to localStorage whenever it changes
  useEffect(() => {
    if (user) {
      localStorage.setItem('medicalAppUser', JSON.stringify(user));
    } else {
      localStorage.removeItem('medicalAppUser');
    }
  }, [user]);

  const login = async (email: string, password: string, role: UserRole) => {
    // Mock authentication - simulates API call
    await new Promise(resolve => setTimeout(resolve, 500));
    
    const mockUser: User = {
      id: role === 'patient' ? 'patient-1' : 'doctor-1',
      name: role === 'patient' ? 'John Doe' : 'Dr. Sarah Johnson',
      email,
      role: role || 'patient'
    };
    
    setUser(mockUser);
  };

  const logout = () => {
    setUser(null);
    localStorage.removeItem('medicalAppUser');
  };

  return (
    <AuthContext.Provider 
      value={{ 
        user, 
        login, 
        logout, 
        isAuthenticated: !!user 
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}