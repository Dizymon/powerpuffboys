import { useState } from 'react';
import { useAuth } from '../../context/AuthContext';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../../components/ui/card';
import { Button } from '../../components/ui/button';
import { Input } from '../../components/ui/input';
import { Label } from '../../components/ui/label';
import { Badge } from '../../components/ui/badge';
import { appointmentService } from '../../services/mockData';
import { Calendar, Clock, Trash2, User, Plus, Edit } from 'lucide-react';
import { toast } from 'sonner';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '../../components/ui/dialog';

export default function ManageAppointmentsPage() {
  const { user } = useAuth();
  const [appointments, setAppointments] = useState(
    user ? appointmentService.getByDentistId(user.id) : []
  );
  const [showCreateDialog, setShowCreateDialog] = useState(false);

  const handleDelete = (appointmentId: string) => {
    if (confirm('Are you sure you want to delete this appointment?')) {
      appointmentService.delete(appointmentId);
      setAppointments(appointments.filter(apt => apt.id !== appointmentId));
      toast.success('Appointment deleted successfully');
    }
  };

  const allAppointments = appointments.filter(apt => apt.status !== 'rejected');

  return (
    <div className="container mx-auto px-4 py-8 max-w-6xl">
      <div className="mb-8 flex items-center justify-between">
        <div>
          <h1 className="text-3xl mb-2">Manage Appointments</h1>
          <p className="text-muted-foreground">
            View and manage your appointment schedule
          </p>
        </div>
        <Dialog open={showCreateDialog} onOpenChange={setShowCreateDialog}>
          <DialogTrigger asChild>
            <Button className="bg-primary hover:bg-primary/90">
              <Plus className="h-4 w-4 mr-2" />
              Create Slot
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Create Appointment Slot</DialogTitle>
              <DialogDescription>
                Add a new available time slot to your schedule
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-4 pt-4">
              <div className="space-y-2">
                <Label htmlFor="slot-date">Date</Label>
                <Input id="slot-date" type="date" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="slot-time">Time</Label>
                <Input id="slot-time" type="time" />
              </div>
              <Button 
                className="w-full bg-primary hover:bg-primary/90"
                onClick={() => {
                  toast.success('Appointment slot created');
                  setShowCreateDialog(false);
                }}
              >
                Create Slot
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      {/* Stats */}
      <div className="grid md:grid-cols-3 gap-6 mb-8">
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground mb-1">Total</p>
                <p className="text-3xl">{allAppointments.length}</p>
              </div>
              <Calendar className="h-8 w-8 text-primary" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground mb-1">Approved</p>
                <p className="text-3xl">{allAppointments.filter(a => a.status === 'approved').length}</p>
              </div>
              <div className="h-8 w-8 rounded-full bg-green-500/10 flex items-center justify-center">
                <User className="h-5 w-5 text-green-600" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground mb-1">Pending</p>
                <p className="text-3xl">{allAppointments.filter(a => a.status === 'pending').length}</p>
              </div>
              <div className="h-8 w-8 rounded-full bg-yellow-500/10 flex items-center justify-center">
                <Clock className="h-5 w-5 text-yellow-600" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Appointments List */}
      {allAppointments.length === 0 ? (
        <Card>
          <CardContent className="py-12 text-center">
            <div className="h-16 w-16 rounded-full bg-muted mx-auto mb-4 flex items-center justify-center">
              <Calendar className="h-8 w-8 text-muted-foreground" />
            </div>
            <h3 className="mb-2">No Appointments</h3>
            <p className="text-muted-foreground mb-6">
              You don't have any appointments scheduled yet.
            </p>
            <Button 
              className="bg-primary hover:bg-primary/90"
              onClick={() => setShowCreateDialog(true)}
            >
              Create First Slot
            </Button>
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-4">
          {allAppointments.map((appointment) => (
            <Card key={appointment.id}>
              <CardContent className="pt-6">
                <div className="flex items-start justify-between gap-4">
                  <div className="flex-1">
                    <div className="flex items-start justify-between mb-3">
                      <div>
                        <h3 className="mb-1 flex items-center gap-2">
                          <User className="h-4 w-4 text-primary" />
                          {appointment.patientName}
                        </h3>
                        <p className="text-sm text-muted-foreground">{appointment.email}</p>
                      </div>
                      <Badge 
                        className={
                          appointment.status === 'approved' 
                            ? 'bg-green-500' 
                            : 'bg-yellow-500'
                        }
                      >
                        {appointment.status}
                      </Badge>
                    </div>

                    <div className="grid md:grid-cols-2 gap-4 mb-4">
                      <div className="flex items-center gap-2 text-sm">
                        <Calendar className="h-4 w-4 text-muted-foreground" />
                        <span className="text-muted-foreground">Date:</span>
                        <span className="font-medium">{new Date(appointment.date).toLocaleDateString()}</span>
                      </div>
                      <div className="flex items-center gap-2 text-sm">
                        <Clock className="h-4 w-4 text-muted-foreground" />
                        <span className="text-muted-foreground">Time:</span>
                        <span className="font-medium">{appointment.timeSlot}</span>
                      </div>
                    </div>

                    {appointment.reason && (
                      <div className="p-3 bg-muted rounded-lg mb-4">
                        <p className="text-sm font-medium mb-1">Reason:</p>
                        <p className="text-sm text-muted-foreground">{appointment.reason}</p>
                      </div>
                    )}

                    <div className="flex gap-2">
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => toast.info('Edit functionality would be implemented here')}
                      >
                        <Edit className="h-4 w-4 mr-2" />
                        Edit
                      </Button>
                      <Button
                        variant="destructive"
                        size="sm"
                        onClick={() => handleDelete(appointment.id)}
                      >
                        <Trash2 className="h-4 w-4 mr-2" />
                        Delete
                      </Button>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
