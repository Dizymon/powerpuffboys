import { useState, useEffect } from 'react';
import { useAuth } from '../../context/AuthContext';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../../components/ui/card';
import { Button } from '../../components/ui/button';
import { Badge } from '../../components/ui/badge';
import { Textarea } from '../../components/ui/textarea';
import { Label } from '../../components/ui/label';
import { appointmentService } from '../../services/mockData';
import { Calendar, Clock, User, Mail, Phone, CheckCircle, XCircle } from 'lucide-react';
import { toast } from 'sonner';

export default function DoctorDashboard() {
  const { user } = useAuth();
  const [appointments, setAppointments] = useState(
    user ? appointmentService.getPending(user.id) : []
  );
  const [selectedAppointment, setSelectedAppointment] = useState<string | null>(null);
  const [notes, setNotes] = useState('');

  // Refresh appointments when localStorage changes
  useEffect(() => {
    const handleStorageChange = () => {
      if (user) {
        setAppointments(appointmentService.getPending(user.id));
      }
    };
    
    window.addEventListener('storage', handleStorageChange);
    return () => window.removeEventListener('storage', handleStorageChange);
  }, [user]);

  const handleApprove = (appointmentId: string) => {
    const notesText = selectedAppointment === appointmentId ? notes : '';
    appointmentService.updateStatus(appointmentId, 'approved', notesText || 'Your appointment has been approved!');
    setAppointments(appointments.filter(apt => apt.id !== appointmentId));
    setSelectedAppointment(null);
    setNotes('');
    toast.success('Appointment approved successfully!');
    // Trigger custom event for other tabs
    window.dispatchEvent(new Event('appointmentUpdate'));
  };

  const handleReject = (appointmentId: string) => {
    const notesText = selectedAppointment === appointmentId ? notes : '';
    appointmentService.updateStatus(appointmentId, 'rejected', notesText || 'Sorry, we cannot accommodate this appointment at the requested time.');
    setAppointments(appointments.filter(apt => apt.id !== appointmentId));
    setSelectedAppointment(null);
    setNotes('');
    toast.success('Appointment rejected.');
    // Trigger custom event for other tabs
    window.dispatchEvent(new Event('appointmentUpdate'));
  };

  return (
    <div className="container mx-auto px-4 py-8 max-w-6xl">
      <div className="mb-8">
        <h1 className="text-3xl mb-2">Pending Appointment Registrations</h1>
        <p className="text-muted-foreground">
          Review and manage incoming appointment requests from patients
        </p>
      </div>

      {appointments.length === 0 ? (
        <Card>
          <CardContent className="py-12 text-center">
            <div className="h-16 w-16 rounded-full bg-muted mx-auto mb-4 flex items-center justify-center">
              <Calendar className="h-8 w-8 text-muted-foreground" />
            </div>
            <h3 className="mb-2">No Pending Appointments</h3>
            <p className="text-muted-foreground">
              All appointment requests have been reviewed. New requests will appear here.
            </p>
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-6">
          {appointments.map((appointment) => (
            <Card key={appointment.id}>
              <CardHeader>
                <div className="flex items-start justify-between">
                  <div>
                    <CardTitle className="flex items-center gap-2">
                      <User className="h-5 w-5 text-primary" />
                      {appointment.patientName}
                    </CardTitle>
                    <CardDescription>
                      <Badge variant="secondary" className="mt-2">Pending Review</Badge>
                    </CardDescription>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                {/* Patient Details */}
                <div className="grid md:grid-cols-2 gap-4 p-4 bg-muted rounded-lg">
                  <div className="space-y-3">
                    <div className="flex items-center gap-2 text-sm">
                      <Mail className="h-4 w-4 text-muted-foreground" />
                      <span className="text-muted-foreground">Email:</span>
                      <span className="font-medium">{appointment.email}</span>
                    </div>
                    <div className="flex items-center gap-2 text-sm">
                      <Phone className="h-4 w-4 text-muted-foreground" />
                      <span className="text-muted-foreground">Phone:</span>
                      <span className="font-medium">{appointment.contactNumber}</span>
                    </div>
                  </div>
                  <div className="space-y-3">
                    <div className="text-sm">
                      <span className="text-muted-foreground">Gender:</span>
                      <span className="font-medium ml-2">{appointment.gender}</span>
                    </div>
                    <div className="text-sm">
                      <span className="text-muted-foreground">Age:</span>
                      <span className="font-medium ml-2">{appointment.age} years</span>
                    </div>
                  </div>
                </div>

                {/* Appointment Details */}
                <div className="grid md:grid-cols-2 gap-4">
                  <div className="flex items-center gap-2 text-sm">
                    <Calendar className="h-4 w-4 text-primary" />
                    <span className="text-muted-foreground">Preferred Date:</span>
                    <span className="font-medium">{new Date(appointment.date).toLocaleDateString()}</span>
                  </div>
                  <div className="flex items-center gap-2 text-sm">
                    <Clock className="h-4 w-4 text-primary" />
                    <span className="text-muted-foreground">Preferred Time:</span>
                    <span className="font-medium">{appointment.timeSlot}</span>
                  </div>
                </div>

                {/* Reason for Consultation */}
                {appointment.reason && (
                  <div className="p-4 bg-white border border-border rounded-lg">
                    <h4 className="text-sm mb-2">Reason for Consultation:</h4>
                    <p className="text-sm text-muted-foreground">{appointment.reason}</p>
                  </div>
                )}

                {/* Notes Section */}
                {selectedAppointment === appointment.id && (
                  <div className="space-y-2">
                    <Label htmlFor={`notes-${appointment.id}`}>
                      Add Notes for Patient (Optional)
                    </Label>
                    <Textarea
                      id={`notes-${appointment.id}`}
                      placeholder="Add any notes or instructions for the patient..."
                      value={notes}
                      onChange={(e) => setNotes(e.target.value)}
                      rows={3}
                    />
                  </div>
                )}

                {/* Action Buttons */}
                <div className="flex gap-3 pt-4">
                  {selectedAppointment !== appointment.id && (
                    <Button
                      variant="outline"
                      onClick={() => {
                        setSelectedAppointment(appointment.id);
                        setNotes('');
                      }}
                      className="flex-1"
                    >
                      Add Notes
                    </Button>
                  )}
                  <Button
                    onClick={() => handleApprove(appointment.id)}
                    className="flex-1 bg-green-600 hover:bg-green-700 text-white"
                  >
                    <CheckCircle className="h-4 w-4 mr-2" />
                    Approve
                  </Button>
                  <Button
                    onClick={() => handleReject(appointment.id)}
                    variant="destructive"
                    className="flex-1"
                  >
                    <XCircle className="h-4 w-4 mr-2" />
                    Reject
                  </Button>
                </div>

                {/* Contact Info */}
                <div className="pt-4 border-t border-border">
                  <p className="text-sm text-muted-foreground">
                    💡 You can contact the patient at {appointment.contactNumber} or {appointment.email} before making a decision.
                  </p>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
