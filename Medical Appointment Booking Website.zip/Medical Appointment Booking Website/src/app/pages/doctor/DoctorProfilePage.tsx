import { useState, useEffect } from 'react';
import { useAuth } from '../../context/AuthContext';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../../components/ui/card';
import { Button } from '../../components/ui/button';
import { Input } from '../../components/ui/input';
import { Label } from '../../components/ui/label';
import { Textarea } from '../../components/ui/textarea';
import { doctorService } from '../../services/mockData';
import { User, Award, Briefcase, Calendar, Plus, X } from 'lucide-react';
import { toast } from 'sonner';

export default function DoctorProfilePage() {
  const { user } = useAuth();
  
  // Get current doctor data from localStorage
  const [currentDoctor, setCurrentDoctor] = useState(() => {
    const doctors = doctorService.getAll();
    return doctors.find(d => d.id === user?.id) || doctors[0];
  });
  
  const [formData, setFormData] = useState({
    name: currentDoctor.name,
    specialization: currentDoctor.specialization,
    credentials: currentDoctor.credentials,
    description: currentDoctor.description,
    availability: currentDoctor.availability
  });

  const [newDay, setNewDay] = useState('');
  const [newSlot, setNewSlot] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    doctorService.updateProfile(currentDoctor.id, formData);
    toast.success('Profile updated successfully!');
    // Trigger update event
    window.dispatchEvent(new Event('doctorProfileUpdate'));
  };

  const addTimeSlot = (dayIndex: number) => {
    if (!newSlot) return;
    
    const updatedAvailability = [...formData.availability];
    updatedAvailability[dayIndex].slots.push(newSlot);
    setFormData({ ...formData, availability: updatedAvailability });
    setNewSlot('');
    toast.success('Time slot added');
  };

  const removeTimeSlot = (dayIndex: number, slotIndex: number) => {
    const updatedAvailability = [...formData.availability];
    updatedAvailability[dayIndex].slots.splice(slotIndex, 1);
    setFormData({ ...formData, availability: updatedAvailability });
    toast.success('Time slot removed');
  };

  const addAvailabilityDay = () => {
    if (!newDay) return;
    
    const updatedAvailability = [
      ...formData.availability,
      { day: newDay, slots: [] }
    ];
    setFormData({ ...formData, availability: updatedAvailability });
    setNewDay('');
    toast.success('Day added to availability');
  };

  const removeAvailabilityDay = (dayIndex: number) => {
    const updatedAvailability = formData.availability.filter((_, idx) => idx !== dayIndex);
    setFormData({ ...formData, availability: updatedAvailability });
    toast.success('Day removed from availability');
  };

  return (
    <div className="container mx-auto px-4 py-8 max-w-4xl">
      <div className="mb-8">
        <h1 className="text-3xl mb-2">Doctor Profile</h1>
        <p className="text-muted-foreground">
          Manage your professional profile and availability
        </p>
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">
        {/* Basic Information */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <User className="h-5 w-5 text-primary" />
              Basic Information
            </CardTitle>
            <CardDescription>Update your personal and professional details</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="name">Full Name</Label>
              <Input
                id="name"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="specialization">Medical Specialization</Label>
              <Input
                id="specialization"
                placeholder="e.g., General Medicine, Cardiology, Pediatrics"
                value={formData.specialization}
                onChange={(e) => setFormData({ ...formData, specialization: e.target.value })}
                required
              />
            </div>
          </CardContent>
        </Card>

        {/* Credentials */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Award className="h-5 w-5 text-primary" />
              Credentials & Certifications
            </CardTitle>
            <CardDescription>List your qualifications and professional memberships</CardDescription>
          </CardHeader>
          <CardContent>
            <Textarea
              placeholder="e.g., MD, Board Certified in Internal Medicine"
              value={formData.credentials}
              onChange={(e) => setFormData({ ...formData, credentials: e.target.value })}
              rows={3}
              required
            />
          </CardContent>
        </Card>

        {/* Professional Description */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Briefcase className="h-5 w-5 text-primary" />
              Professional Description
            </CardTitle>
            <CardDescription>Tell patients about your experience and approach</CardDescription>
          </CardHeader>
          <CardContent>
            <Textarea
              placeholder="Describe your experience, specialties, and approach to patient care..."
              value={formData.description}
              onChange={(e) => setFormData({ ...formData, description: e.target.value })}
              rows={5}
              required
            />
          </CardContent>
        </Card>

        {/* Availability Management */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Calendar className="h-5 w-5 text-primary" />
              Weekly Availability
            </CardTitle>
            <CardDescription>Manage your available days and time slots</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            {formData.availability.map((avail, dayIndex) => (
              <div key={dayIndex} className="border border-border rounded-lg p-4">
                <div className="flex items-center justify-between mb-3">
                  <h4>{avail.day}</h4>
                  <Button
                    type="button"
                    variant="ghost"
                    size="sm"
                    onClick={() => removeAvailabilityDay(dayIndex)}
                  >
                    <X className="h-4 w-4" />
                  </Button>
                </div>

                <div className="space-y-2">
                  <Label>Time Slots</Label>
                  <div className="flex flex-wrap gap-2 mb-2">
                    {avail.slots.map((slot, slotIndex) => (
                      <div
                        key={slotIndex}
                        className="flex items-center gap-1 bg-muted px-3 py-1 rounded-md"
                      >
                        <span className="text-sm">{slot}</span>
                        <button
                          type="button"
                          onClick={() => removeTimeSlot(dayIndex, slotIndex)}
                          className="ml-1 text-muted-foreground hover:text-destructive"
                        >
                          <X className="h-3 w-3" />
                        </button>
                      </div>
                    ))}
                  </div>

                  <div className="flex gap-2">
                    <Input
                      type="text"
                      value={newSlot}
                      onChange={(e) => setNewSlot(e.target.value)}
                      placeholder="e.g., 9:00 AM, 2:00 PM"
                    />
                    <Button
                      type="button"
                      variant="outline"
                      onClick={() => addTimeSlot(dayIndex)}
                    >
                      <Plus className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </div>
            ))}

            {/* Add New Day */}
            <div className="border-2 border-dashed border-border rounded-lg p-4">
              <Label htmlFor="new-day" className="mb-2 block">Add New Day</Label>
              <div className="flex gap-2">
                <Input
                  id="new-day"
                  placeholder="e.g., Monday, Tuesday"
                  value={newDay}
                  onChange={(e) => setNewDay(e.target.value)}
                />
                <Button
                  type="button"
                  variant="outline"
                  onClick={addAvailabilityDay}
                >
                  <Plus className="h-4 w-4 mr-2" />
                  Add Day
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Save Button */}
        <div className="flex justify-end gap-4">
          <Button type="button" variant="outline">
            Cancel
          </Button>
          <Button type="submit" className="bg-primary hover:bg-primary/90">
            Save Changes
          </Button>
        </div>
      </form>
    </div>
  );
}
