import { useState } from 'react';
import { useParams, useNavigate } from 'react-router';
import { useAuth } from '../../context/AuthContext';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../../components/ui/card';
import { Button } from '../../components/ui/button';
import { Input } from '../../components/ui/input';
import { Label } from '../../components/ui/label';
import { Textarea } from '../../components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../../components/ui/select';
import { Badge } from '../../components/ui/badge';
import { doctorService, appointmentService } from '../../services/mockData';
import { ArrowLeft, CheckCircle } from 'lucide-react';
import { toast } from 'sonner';

export default function AppointmentRegistrationPage() {
  const { doctorId } = useParams();
  const { user } = useAuth();
  const navigate = useNavigate();
  const doctor = doctorId ? doctorService.getById(doctorId) : null;

  const [formData, setFormData] = useState({
    fullName: user?.name || '',
    contactNumber: '',
    email: user?.email || '',
    gender: '',
    age: '',
    reason: '',
    selectedDay: '',
    selectedTimeSlot: ''
  });

  const [showConfirmation, setShowConfirmation] = useState(false);

  if (!doctor) {
    return (
      <div className="container mx-auto px-4 py-8 max-w-4xl">
        <Card>
          <CardContent className="py-12 text-center">
            <h2 className="text-2xl mb-2">Doctor Not Found</h2>
            <Button onClick={() => navigate('/patient/appointments')}>
              Back to Doctors
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  const selectedDaySlots = formData.selectedDay 
    ? doctor.availability.find(a => a.day === formData.selectedDay)?.slots || []
    : [];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setShowConfirmation(true);
  };

  const handleConfirmSubmit = () => {
    if (!user) return;

    // Create appointment
    const appointment = appointmentService.create({
      patientId: user.id,
      doctorId: doctor.id,
      patientName: formData.fullName,
      contactNumber: formData.contactNumber,
      email: formData.email,
      gender: formData.gender,
      age: formData.age,
      reason: formData.reason,
      date: new Date().toISOString().split('T')[0], // Mock date
      timeSlot: formData.selectedTimeSlot,
      status: 'pending'
    });

    toast.success('Appointment request submitted successfully!');
    // Trigger update event
    window.dispatchEvent(new Event('appointmentUpdate'));
    navigate('/patient/dashboard');
  };

  if (showConfirmation) {
    return (
      <div className="container mx-auto px-4 py-8 max-w-2xl">
        <Card>
          <CardHeader className="text-center">
            <div className="h-16 w-16 rounded-full bg-green-500/10 flex items-center justify-center mx-auto mb-4">
              <CheckCircle className="h-8 w-8 text-green-600" />
            </div>
            <CardTitle>Confirm Your Appointment</CardTitle>
            <CardDescription>Please review your information before submitting</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="bg-muted p-4 rounded-lg space-y-3">
              <div className="flex justify-between">
                <span className="text-muted-foreground">Doctor:</span>
                <span className="font-medium">{doctor.name}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Specialization:</span>
                <Badge variant="secondary">{doctor.specialization}</Badge>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Your Name:</span>
                <span className="font-medium">{formData.fullName}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Contact:</span>
                <span className="font-medium">{formData.contactNumber}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Email:</span>
                <span className="font-medium">{formData.email}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Preferred Day:</span>
                <span className="font-medium">{formData.selectedDay}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Preferred Time:</span>
                <span className="font-medium">{formData.selectedTimeSlot}</span>
              </div>
            </div>

            <div className="flex gap-3">
              <Button 
                variant="outline" 
                className="flex-1"
                onClick={() => setShowConfirmation(false)}
              >
                Edit Information
              </Button>
              <Button 
                className="flex-1 bg-primary hover:bg-primary/90"
                onClick={handleConfirmSubmit}
              >
                Confirm & Submit
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-8 max-w-2xl">
      <Button 
        variant="ghost" 
        className="mb-6"
        onClick={() => navigate(`/patient/doctor/${doctor.id}`)}
      >
        <ArrowLeft className="h-4 w-4 mr-2" />
        Back to Profile
      </Button>

      <Card>
        <CardHeader>
          <CardTitle>Register Appointment</CardTitle>
          <CardDescription>
            Booking with {doctor.name} - {doctor.specialization}
          </CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="fullName">Full Name *</Label>
                <Input
                  id="fullName"
                  value={formData.fullName}
                  onChange={(e) => setFormData({ ...formData, fullName: e.target.value })}
                  required
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="contactNumber">Contact Number *</Label>
                <Input
                  id="contactNumber"
                  type="tel"
                  placeholder="555-0123"
                  value={formData.contactNumber}
                  onChange={(e) => setFormData({ ...formData, contactNumber: e.target.value })}
                  required
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="email">Email Address *</Label>
              <Input
                id="email"
                type="email"
                value={formData.email}
                onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                required
              />
            </div>

            <div className="grid md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="gender">Gender *</Label>
                <Select 
                  value={formData.gender}
                  onValueChange={(value) => setFormData({ ...formData, gender: value })}
                  required
                >
                  <SelectTrigger id="gender">
                    <SelectValue placeholder="Select gender" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Male">Male</SelectItem>
                    <SelectItem value="Female">Female</SelectItem>
                    <SelectItem value="Other">Other</SelectItem>
                    <SelectItem value="Prefer not to say">Prefer not to say</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="age">Age *</Label>
                <Input
                  id="age"
                  type="number"
                  min="1"
                  max="120"
                  placeholder="25"
                  value={formData.age}
                  onChange={(e) => setFormData({ ...formData, age: e.target.value })}
                  required
                />
              </div>
            </div>

            <div className="grid md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="day">Preferred Day *</Label>
                <Select 
                  value={formData.selectedDay}
                  onValueChange={(value) => setFormData({ ...formData, selectedDay: value, selectedTimeSlot: '' })}
                  required
                >
                  <SelectTrigger id="day">
                    <SelectValue placeholder="Select day" />
                  </SelectTrigger>
                  <SelectContent>
                    {doctor.availability.map((avail) => (
                      <SelectItem key={avail.day} value={avail.day}>
                        {avail.day}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="timeSlot">Preferred Time *</Label>
                <Select 
                  value={formData.selectedTimeSlot}
                  onValueChange={(value) => setFormData({ ...formData, selectedTimeSlot: value })}
                  required
                  disabled={!formData.selectedDay}
                >
                  <SelectTrigger id="timeSlot">
                    <SelectValue placeholder="Select time slot" />
                  </SelectTrigger>
                  <SelectContent>
                    {selectedDaySlots.map((slot) => (
                      <SelectItem key={slot} value={slot}>
                        {slot}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="reason">Reason for Consultation (Optional)</Label>
              <Textarea
                id="reason"
                placeholder="Describe your medical concern or reason for consultation..."
                rows={4}
                value={formData.reason}
                onChange={(e) => setFormData({ ...formData, reason: e.target.value })}
              />
            </div>

            <Button type="submit" className="w-full bg-primary hover:bg-primary/90">
              Submit Appointment Request
            </Button>
          </form>
        </CardContent>
      </Card>
    </div>
  );
}