import { Link } from 'react-router';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../../components/ui/card';
import { Button } from '../../components/ui/button';
import { Badge } from '../../components/ui/badge';
import { doctorService } from '../../services/mockData';
import { Calendar, Clock } from 'lucide-react';

export default function AppointmentsPage() {
  const doctors = doctorService.getAll();

  return (
    <div className="container mx-auto px-4 py-8 max-w-6xl">
      <div className="mb-8">
        <h1 className="text-3xl mb-2">Book an Appointment</h1>
        <p className="text-muted-foreground">
          Browse our licensed doctors and select a time that works for you
        </p>
      </div>

      {/* Doctor Cards Grid */}
      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
        {doctors.map((doctor) => (
          <Card key={doctor.id} className="flex flex-col hover:shadow-lg transition-shadow">
            <CardHeader>
              <div className="h-20 w-20 rounded-full bg-gradient-to-br from-primary to-accent mx-auto mb-4 flex items-center justify-center text-white text-2xl">
                {doctor.name.split(' ').map(n => n[0]).join('')}
              </div>
              <CardTitle className="text-center">{doctor.name}</CardTitle>
              <CardDescription className="text-center">
                <Badge variant="secondary" className="mt-2">
                  {doctor.specialization}
                </Badge>
              </CardDescription>
            </CardHeader>
            <CardContent className="flex-1 flex flex-col">
              <div className="mb-4">
                <h4 className="text-sm mb-2">Weekly Availability:</h4>
                <div className="space-y-2">
                  {doctor.availability.slice(0, 2).map((avail, idx) => (
                    <div key={idx} className="flex items-start gap-2 text-sm">
                      <Calendar className="h-4 w-4 text-primary mt-0.5 flex-shrink-0" />
                      <div>
                        <span className="font-medium">{avail.day}:</span>
                        <div className="text-muted-foreground">
                          {avail.slots.slice(0, 3).join(', ')}
                          {avail.slots.length > 3 && '...'}
                        </div>
                      </div>
                    </div>
                  ))}
                  {doctor.availability.length > 2 && (
                    <p className="text-sm text-muted-foreground">
                      +{doctor.availability.length - 2} more days
                    </p>
                  )}
                </div>
              </div>
              
              <div className="mt-auto pt-4">
                <Link to={`/patient/doctor/${doctor.id}`}>
                  <Button className="w-full bg-primary hover:bg-primary/90">
                    View Details & Book
                  </Button>
                </Link>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}