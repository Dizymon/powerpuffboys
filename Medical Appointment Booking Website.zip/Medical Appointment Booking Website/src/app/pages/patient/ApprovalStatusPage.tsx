import { useAuth } from '../../context/AuthContext';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../../components/ui/card';
import { Badge } from '../../components/ui/badge';
import { appointmentService, doctorService } from '../../services/mockData';
import { Calendar, Clock, CheckCircle, XCircle, AlertCircle } from 'lucide-react';
import { useState, useEffect } from 'react';

export default function ApprovalStatusPage() {
  const { user } = useAuth();
  const [appointments, setAppointments] = useState(
    user ? appointmentService.getByPatientId(user.id) : []
  );

  // Refresh appointments when updates occur
  useEffect(() => {
    const handleUpdate = () => {
      if (user) {
        setAppointments(appointmentService.getByPatientId(user.id));
      }
    };
    
    window.addEventListener('appointmentUpdate', handleUpdate);
    window.addEventListener('storage', handleUpdate);
    
    return () => {
      window.removeEventListener('appointmentUpdate', handleUpdate);
      window.removeEventListener('storage', handleUpdate);
    };
  }, [user]);

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'approved':
        return <CheckCircle className="h-6 w-6 text-green-600" />;
      case 'rejected':
        return <XCircle className="h-6 w-6 text-red-600" />;
      default:
        return <AlertCircle className="h-6 w-6 text-yellow-600" />;
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'approved':
        return <Badge className="bg-green-500">Approved</Badge>;
      case 'rejected':
        return <Badge className="bg-red-500">Rejected</Badge>;
      default:
        return <Badge className="bg-yellow-500">Pending</Badge>;
    }
  };

  return (
    <div className="container mx-auto px-4 py-8 max-w-6xl">
      <div className="mb-8">
        <h1 className="text-3xl mb-2">Appointment Status</h1>
        <p className="text-muted-foreground">
          Track the approval status of your appointment requests
        </p>
      </div>

      {appointments.length === 0 ? (
        <Card>
          <CardContent className="py-12 text-center">
            <div className="h-16 w-16 rounded-full bg-muted mx-auto mb-4 flex items-center justify-center">
              <Calendar className="h-8 w-8 text-muted-foreground" />
            </div>
            <h3 className="mb-2">No Appointments Found</h3>
            <p className="text-muted-foreground">
              You haven't submitted any appointment requests yet.
            </p>
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-4">
          {appointments.map((appointment) => {
            const doctor = doctorService.getById(appointment.doctorId);
            return (
              <Card key={appointment.id}>
                <CardContent className="pt-6">
                  <div className="flex items-start justify-between gap-4">
                    <div className="flex items-start gap-4 flex-1">
                      <div className="h-12 w-12 rounded-full bg-muted flex items-center justify-center flex-shrink-0">
                        {getStatusIcon(appointment.status)}
                      </div>
                      <div className="flex-1">
                        <div className="flex items-start justify-between mb-2">
                          <div>
                            <h3 className="mb-1">{doctor?.name}</h3>
                            <p className="text-sm text-muted-foreground">{doctor?.specialization}</p>
                          </div>
                          {getStatusBadge(appointment.status)}
                        </div>
                        
                        <div className="grid md:grid-cols-2 gap-4 mt-4 text-sm">
                          <div className="space-y-2">
                            <div className="flex items-center gap-2 text-muted-foreground">
                              <Calendar className="h-4 w-4" />
                              <span>Preferred Day: {appointment.date ? new Date(appointment.date).toLocaleDateString() : 'Not specified'}</span>
                            </div>
                            <div className="flex items-center gap-2 text-muted-foreground">
                              <Clock className="h-4 w-4" />
                              <span>Preferred Time: {appointment.timeSlot}</span>
                            </div>
                          </div>
                          <div className="space-y-2">
                            <div className="text-muted-foreground">
                              <span className="font-medium">Contact:</span> {appointment.contactNumber}
                            </div>
                            <div className="text-muted-foreground">
                              <span className="font-medium">Email:</span> {appointment.email}
                            </div>
                          </div>
                        </div>

                        {appointment.reason && (
                          <div className="mt-4 p-3 bg-muted rounded-lg">
                            <p className="text-sm font-medium mb-1">Reason for Consultation:</p>
                            <p className="text-sm text-muted-foreground">{appointment.reason}</p>
                          </div>
                        )}

                        {appointment.doctorNotes && (
                          <div className="mt-4 p-3 bg-primary/5 border border-primary/20 rounded-lg">
                            <p className="text-sm font-medium mb-1 text-primary">Doctor Notes:</p>
                            <p className="text-sm text-muted-foreground">{appointment.doctorNotes}</p>
                          </div>
                        )}

                        {appointment.status === 'pending' && (
                          <div className="mt-4 p-3 bg-yellow-50 border border-yellow-200 rounded-lg">
                            <p className="text-sm text-yellow-800">
                              ⏳ Your appointment request is pending review. The doctor will respond soon.
                            </p>
                          </div>
                        )}

                        {appointment.status === 'approved' && (
                          <div className="mt-4 p-3 bg-green-50 border border-green-200 rounded-lg">
                            <p className="text-sm text-green-800">
                              ✅ Your appointment has been approved! You will receive a confirmation shortly.
                            </p>
                          </div>
                        )}

                        {appointment.status === 'rejected' && (
                          <div className="mt-4 p-3 bg-red-50 border border-red-200 rounded-lg">
                            <p className="text-sm text-red-800">
                              ❌ Unfortunately, this appointment request was not approved. Please try booking a different time slot.
                            </p>
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      )}
    </div>
  );
}