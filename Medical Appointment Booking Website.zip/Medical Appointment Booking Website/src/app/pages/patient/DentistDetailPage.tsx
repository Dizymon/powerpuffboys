import { useParams, Link, useNavigate } from 'react-router';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../../components/ui/card';
import { Button } from '../../components/ui/button';
import { Badge } from '../../components/ui/badge';
import { dentistService } from '../../services/mockData';
import { Calendar, Award, Briefcase, ArrowLeft } from 'lucide-react';

export default function DentistDetailPage() {
  const { dentistId } = useParams();
  const navigate = useNavigate();
  const dentist = dentistId ? dentistService.getById(dentistId) : null;

  if (!dentist) {
    return (
      <div className="container mx-auto px-4 py-8 max-w-4xl">
        <Card>
          <CardContent className="py-12 text-center">
            <h2 className="text-2xl mb-2">Dentist Not Found</h2>
            <p className="text-muted-foreground mb-6">
              The dentist you're looking for doesn't exist.
            </p>
            <Link to="/patient/appointments">
              <Button>Back to Dentists</Button>
            </Link>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-8 max-w-4xl">
      {/* Back Button */}
      <Button 
        variant="ghost" 
        className="mb-6"
        onClick={() => navigate('/patient/appointments')}
      >
        <ArrowLeft className="h-4 w-4 mr-2" />
        Back to Dentists
      </Button>

      {/* Dentist Profile */}
      <Card className="mb-6">
        <CardHeader className="text-center pb-4">
          <div className="h-32 w-32 rounded-full bg-gradient-to-br from-primary to-accent mx-auto mb-4 flex items-center justify-center text-white text-4xl">
            {dentist.name.split(' ').map(n => n[0]).join('')}
          </div>
          <CardTitle className="text-3xl">{dentist.name}</CardTitle>
          <CardDescription>
            <Badge variant="secondary" className="mt-2">
              {dentist.specialization}
            </Badge>
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Credentials */}
          <div>
            <div className="flex items-center gap-2 mb-3">
              <Award className="h-5 w-5 text-primary" />
              <h3>Credentials</h3>
            </div>
            <p className="text-muted-foreground pl-7">{dentist.credentials}</p>
          </div>

          {/* Description */}
          <div>
            <div className="flex items-center gap-2 mb-3">
              <Briefcase className="h-5 w-5 text-primary" />
              <h3>About</h3>
            </div>
            <p className="text-muted-foreground pl-7">{dentist.description}</p>
          </div>

          {/* Availability Schedule */}
          <div>
            <div className="flex items-center gap-2 mb-3">
              <Calendar className="h-5 w-5 text-primary" />
              <h3>Weekly Availability</h3>
            </div>
            <div className="pl-7 space-y-3">
              {dentist.availability.map((avail, idx) => (
                <div key={idx} className="border-l-2 border-primary/30 pl-4 py-2">
                  <p className="font-medium mb-1">{avail.day}</p>
                  <div className="flex flex-wrap gap-2">
                    {avail.slots.map((slot, slotIdx) => (
                      <Badge key={slotIdx} variant="outline" className="bg-white">
                        {slot}
                      </Badge>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Register Appointment CTA */}
      <Card className="bg-primary text-white">
        <CardContent className="py-8 text-center">
          <h3 className="text-2xl mb-2">Ready to Book?</h3>
          <p className="mb-6 opacity-90">
            Schedule your appointment with {dentist.name.split(' ')[1]}
          </p>
          <Link to={`/patient/register-appointment/${dentist.id}`}>
            <Button size="lg" variant="secondary" className="bg-white text-primary hover:bg-white/90">
              Register Appointment
            </Button>
          </Link>
        </CardContent>
      </Card>
    </div>
  );
}
