import { useParams, Link, useNavigate } from 'react-router';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../../components/ui/card';
import { Button } from '../../components/ui/button';
import { Badge } from '../../components/ui/badge';
import { doctorService } from '../../services/mockData';
import { Calendar, Award, Briefcase, ArrowLeft } from 'lucide-react';

export default function DoctorDetailPage() {
  const { doctorId } = useParams();
  const navigate = useNavigate();
  const doctor = doctorId ? doctorService.getById(doctorId) : null;

  if (!doctor) {
    return (
      <div className="container mx-auto px-4 py-8 max-w-4xl">
        <Card>
          <CardContent className="py-12 text-center">
            <h2 className="text-2xl mb-2">Doctor Not Found</h2>
            <p className="text-muted-foreground mb-6">
              The doctor you're looking for doesn't exist.
            </p>
            <Link to="/patient/appointments">
              <Button>Back to Doctors</Button>
            </Link>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-8 max-w-4xl">
      {/* Back Button */}
      <Button 
        variant="ghost" 
        className="mb-6"
        onClick={() => navigate('/patient/appointments')}
      >
        <ArrowLeft className="h-4 w-4 mr-2" />
        Back to Doctors
      </Button>

      {/* Doctor Profile */}
      <Card className="mb-6">
        <CardHeader className="text-center pb-4">
          <div className="h-32 w-32 rounded-full bg-gradient-to-br from-primary to-accent mx-auto mb-4 flex items-center justify-center text-white text-4xl">
            {doctor.name.split(' ').map(n => n[0]).join('')}
          </div>
          <CardTitle className="text-3xl">{doctor.name}</CardTitle>
          <CardDescription>
            <Badge variant="secondary" className="mt-2">
              {doctor.specialization}
            </Badge>
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          {/* Credentials */}
          <div>
            <div className="flex items-center gap-2 mb-3">
              <Award className="h-5 w-5 text-primary" />
              <h3>Credentials</h3>
            </div>
            <p className="text-muted-foreground pl-7">{doctor.credentials}</p>
          </div>

          {/* Description */}
          <div>
            <div className="flex items-center gap-2 mb-3">
              <Briefcase className="h-5 w-5 text-primary" />
              <h3>About</h3>
            </div>
            <p className="text-muted-foreground pl-7">{doctor.description}</p>
          </div>

          {/* Availability Schedule */}
          <div>
            <div className="flex items-center gap-2 mb-3">
              <Calendar className="h-5 w-5 text-primary" />
              <h3>Weekly Availability</h3>
            </div>
            <div className="pl-7 space-y-3">
              {doctor.availability.map((avail, idx) => (
                <div key={idx} className="border-l-2 border-primary/30 pl-4 py-2">
                  <p className="font-medium mb-1">{avail.day}</p>
                  <div className="flex flex-wrap gap-2">
                    {avail.slots.map((slot, slotIdx) => (
                      <Badge key={slotIdx} variant="outline" className="bg-white">
                        {slot}
                      </Badge>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Register Appointment CTA */}
      <Card className="bg-primary text-white">
        <CardContent className="py-8 text-center">
          <h3 className="text-2xl mb-2">Ready to Book?</h3>
          <p className="mb-6 opacity-90">
            Schedule your consultation with {doctor.name.split(' ')[1]}
          </p>
          <Link to={`/patient/register-appointment/${doctor.id}`}>
            <Button size="lg" variant="secondary" className="bg-white text-primary hover:bg-white/90">
              Register Appointment
            </Button>
          </Link>
        </CardContent>
      </Card>
    </div>
  );
}
