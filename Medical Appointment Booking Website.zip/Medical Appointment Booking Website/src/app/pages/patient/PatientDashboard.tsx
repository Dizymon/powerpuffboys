import { useAuth } from '../../context/AuthContext';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../../components/ui/card';
import { Button } from '../../components/ui/button';
import { Link } from 'react-router';
import { Calendar, Clock, CheckCircle, XCircle, AlertCircle } from 'lucide-react';
import { appointmentService, doctorService } from '../../services/mockData';
import { Badge } from '../../components/ui/badge';
import { useState, useEffect } from 'react';

export default function PatientDashboard() {
  const { user } = useAuth();
  const [appointments, setAppointments] = useState(
    user ? appointmentService.getByPatientId(user.id) : []
  );

  // Refresh appointments when updates occur
  useEffect(() => {
    const handleUpdate = () => {
      if (user) {
        setAppointments(appointmentService.getByPatientId(user.id));
      }
    };
    
    window.addEventListener('appointmentUpdate', handleUpdate);
    window.addEventListener('storage', handleUpdate);
    
    return () => {
      window.removeEventListener('appointmentUpdate', handleUpdate);
      window.removeEventListener('storage', handleUpdate);
    };
  }, [user]);
  
  const upcomingAppointments = appointments.filter(apt => apt.status === 'approved');
  const pendingAppointments = appointments.filter(apt => apt.status === 'pending');

  return (
    <div className="container mx-auto px-4 py-8 max-w-6xl">
      {/* Welcome Section */}
      <div className="mb-8">
        <h1 className="text-3xl mb-2">Welcome, {user?.name}!</h1>
        <p className="text-muted-foreground">
          Manage your medical appointments and track their status
        </p>
      </div>

      {/* Stats Cards */}
      <div className="grid md:grid-cols-3 gap-6 mb-8">
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground mb-1">Total Appointments</p>
                <p className="text-3xl">{appointments.length}</p>
              </div>
              <div className="h-12 w-12 rounded-full bg-primary/10 flex items-center justify-center">
                <Calendar className="h-6 w-6 text-primary" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground mb-1">Pending Approval</p>
                <p className="text-3xl">{pendingAppointments.length}</p>
              </div>
              <div className="h-12 w-12 rounded-full bg-yellow-500/10 flex items-center justify-center">
                <Clock className="h-6 w-6 text-yellow-600" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground mb-1">Approved</p>
                <p className="text-3xl">{upcomingAppointments.length}</p>
              </div>
              <div className="h-12 w-12 rounded-full bg-green-500/10 flex items-center justify-center">
                <CheckCircle className="h-6 w-6 text-green-600" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Quick Actions */}
      <Card className="mb-8">
        <CardHeader>
          <CardTitle>Quick Actions</CardTitle>
          <CardDescription>Get started with booking your next medical consultation</CardDescription>
        </CardHeader>
        <CardContent className="flex gap-4">
          <Link to="/patient/appointments">
            <Button className="bg-primary hover:bg-primary/90">
              Book New Appointment
            </Button>
          </Link>
          {appointments.length > 0 && (
            <Link to="/patient/approval-status">
              <Button variant="outline">
                View Appointment Status
              </Button>
            </Link>
          )}
        </CardContent>
      </Card>

      {/* Upcoming Appointments */}
      {upcomingAppointments.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle>Upcoming Appointments</CardTitle>
            <CardDescription>Your confirmed medical consultations</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {upcomingAppointments.map((appointment) => {
                const doctor = doctorService.getById(appointment.doctorId);
                return (
                  <div 
                    key={appointment.id}
                    className="flex items-center justify-between p-4 border border-border rounded-lg bg-white"
                  >
                    <div className="flex items-start gap-4">
                      <div className="h-12 w-12 rounded-full bg-green-500/10 flex items-center justify-center">
                        <CheckCircle className="h-6 w-6 text-green-600" />
                      </div>
                      <div>
                        <h4 className="mb-1">{doctor?.name}</h4>
                        <p className="text-sm text-muted-foreground">{doctor?.specialization}</p>
                        <div className="flex gap-4 mt-2 text-sm text-muted-foreground">
                          <span className="flex items-center gap-1">
                            <Calendar className="h-4 w-4" />
                            {new Date(appointment.date).toLocaleDateString()}
                          </span>
                          <span className="flex items-center gap-1">
                            <Clock className="h-4 w-4" />
                            {appointment.timeSlot}
                          </span>
                        </div>
                      </div>
                    </div>
                    <Badge className="bg-green-500">Approved</Badge>
                  </div>
                );
              })}
            </div>
          </CardContent>
        </Card>
      )}

      {/* No Appointments Message */}
      {appointments.length === 0 && (
        <Card>
          <CardContent className="py-12 text-center">
            <div className="h-16 w-16 rounded-full bg-muted mx-auto mb-4 flex items-center justify-center">
              <Calendar className="h-8 w-8 text-muted-foreground" />
            </div>
            <h3 className="mb-2">No Appointments Yet</h3>
            <p className="text-muted-foreground mb-6">
              Start by booking your first medical appointment
            </p>
            <Link to="/patient/appointments">
              <Button className="bg-primary hover:bg-primary/90">
                Browse Doctors
              </Button>
            </Link>
          </CardContent>
        </Card>
      )}
    </div>
  );
}