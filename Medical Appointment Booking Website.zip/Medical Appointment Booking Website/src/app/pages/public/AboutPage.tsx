import { Link } from 'react-router';
import { Button } from '../../components/ui/button';
import { Activity } from 'lucide-react';

export default function AboutPage() {
  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border bg-white">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <Link to="/" className="flex items-center gap-2">
              <div className="h-10 w-10 rounded-full bg-primary flex items-center justify-center">
                <Activity className="h-6 w-6 text-white" />
              </div>
              <h1 className="text-xl">Medical Appointment System</h1>
            </Link>
            <nav className="flex gap-6">
              <Link to="/" className="text-foreground hover:text-primary transition-colors">
                Home
              </Link>
              <Link to="/about" className="text-foreground hover:text-primary transition-colors">
                About
              </Link>
              <Link to="/contact" className="text-foreground hover:text-primary transition-colors">
                Contact
              </Link>
              <Link to="/login">
                <Button className="bg-primary hover:bg-primary/90">Login</Button>
              </Link>
            </nav>
          </div>
        </div>
      </header>

      {/* Content */}
      <div className="container mx-auto px-4 py-16 max-w-4xl">
        <h1 className="text-4xl mb-8">About Our Medical Appointment System</h1>
        
        <div className="prose prose-lg max-w-none space-y-6">
          <p className="text-lg text-muted-foreground">
            This Medical Appointment Booking System was developed by Team Developers as a scalable, 
            role-based healthcare scheduling solution.
          </p>

          <section>
            <h2 className="text-2xl mb-4">System Overview</h2>
            <p className="text-muted-foreground">
              The system is designed to improve clinic and hospital scheduling efficiency, provide 
              structured patient-doctor appointment workflows, reduce administrative workload, enforce 
              strict role-based access control, and securely manage healthcare data.
            </p>
          </section>

          <section>
            <h2 className="text-2xl mb-4">For Patients</h2>
            <p className="text-muted-foreground mb-3">
              Browse through our network of licensed doctors, each with their own medical specializations 
              and expertise. View their credentials, availability, and book appointments that fit your schedule.
            </p>
            <ul className="list-disc list-inside text-muted-foreground space-y-2">
              <li>View detailed doctor profiles with credentials and specializations</li>
              <li>See real-time availability and choose convenient time slots</li>
              <li>Track appointment status and receive updates</li>
              <li>Manage all your medical appointments in one place</li>
            </ul>
          </section>

          <section>
            <h2 className="text-2xl mb-4">For Doctors</h2>
            <p className="text-muted-foreground mb-3">
              Our platform provides medical professionals with powerful tools to manage their practice 
              efficiently and connect with patients.
            </p>
            <ul className="list-disc list-inside text-muted-foreground space-y-2">
              <li>Manage appointment requests and availability</li>
              <li>Review patient information before consultations</li>
              <li>Update professional profiles and credentials</li>
              <li>Streamline scheduling and reduce administrative overhead</li>
            </ul>
          </section>

          <section>
            <h2 className="text-2xl mb-4">Development Team</h2>
            <p className="text-muted-foreground mb-3">
              This system was developed by Team Developers:
            </p>
            <ul className="list-disc list-inside text-muted-foreground space-y-2">
              <li>Flores, Gian Rusell</li>
              <li>Natividad, James</li>
              <li>Cayetano, James Russell D.</li>
              <li>Ramos, Tristan</li>
              <li>Dingal, Zymon Timothy</li>
            </ul>
          </section>

          <section>
            <h2 className="text-2xl mb-4">Technical Architecture</h2>
            <p className="text-muted-foreground">
              The architecture follows modern full-stack development standards using structured database 
              design, secure authentication, RESTful APIs, and production-ready implementation principles.
            </p>
          </section>

          <div className="mt-12 p-6 bg-white rounded-lg border border-border">
            <h3 className="text-xl mb-3">Ready to get started?</h3>
            <p className="text-muted-foreground mb-4">
              Join our platform for efficient medical appointment scheduling.
            </p>
            <Link to="/login">
              <Button className="bg-primary hover:bg-primary/90">
                Login Now
              </Button>
            </Link>
          </div>
        </div>
      </div>

      {/* Footer */}
      <footer className="border-t border-border bg-white py-8 px-4 mt-16">
        <div className="container mx-auto text-center">
          <div className="mb-4">
            <p className="font-medium mb-2">Developed by Team Developers</p>
            <div className="text-muted-foreground text-sm space-y-1">
              <p>Flores, Gian Rusell • Natividad, James • Cayetano, James Russell D.</p>
              <p>Ramos, Tristan • Dingal, Zymon Timothy</p>
            </div>
          </div>
          <p className="text-muted-foreground">&copy; 2026 Medical Appointment System. All Rights Reserved.</p>
        </div>
      </footer>
    </div>
  );
}