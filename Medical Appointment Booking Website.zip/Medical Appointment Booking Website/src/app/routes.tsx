import { createBrowserRouter, Navigate } from 'react-router';
import { useAuth } from './context/AuthContext';

// Public pages
import HomePage from './pages/public/HomePage';
import LoginPage from './pages/public/LoginPage';
import AboutPage from './pages/public/AboutPage';
import ContactPage from './pages/public/ContactPage';

// Patient pages
import PatientLayout from './components/layout/PatientLayout';
import PatientDashboard from './pages/patient/PatientDashboard';
import AppointmentsPage from './pages/patient/AppointmentsPage';
import DoctorDetailPage from './pages/patient/DoctorDetailPage';
import AppointmentRegistrationPage from './pages/patient/AppointmentRegistrationPage';
import ApprovalStatusPage from './pages/patient/ApprovalStatusPage';

// Doctor pages
import DoctorLayout from './components/layout/DoctorLayout';
import DoctorDashboard from './pages/doctor/DoctorDashboard';
import ManageAppointmentsPage from './pages/doctor/ManageAppointmentsPage';
import DoctorProfilePage from './pages/doctor/DoctorProfilePage';

// Protected Route Component
function ProtectedRoute({ 
  children, 
  allowedRole 
}: { 
  children: React.ReactNode; 
  allowedRole: 'patient' | 'doctor';
}) {
  const { user, isAuthenticated } = useAuth();

  if (!isAuthenticated) {
    return <Navigate to="/login" replace />;
  }

  if (user?.role !== allowedRole) {
    return <Navigate to="/" replace />;
  }

  return <>{children}</>;
}

export const router = createBrowserRouter([
  // Public routes
  {
    path: '/',
    element: <HomePage />,
  },
  {
    path: '/login',
    element: <LoginPage />,
  },
  {
    path: '/about',
    element: <AboutPage />,
  },
  {
    path: '/contact',
    element: <ContactPage />,
  },
  
  // Patient routes
  {
    path: '/patient',
    element: (
      <ProtectedRoute allowedRole="patient">
        <PatientLayout />
      </ProtectedRoute>
    ),
    children: [
      {
        index: true,
        element: <Navigate to="/patient/dashboard" replace />,
      },
      {
        path: 'dashboard',
        element: <PatientDashboard />,
      },
      {
        path: 'appointments',
        element: <AppointmentsPage />,
      },
      {
        path: 'doctor/:doctorId',
        element: <DoctorDetailPage />,
      },
      {
        path: 'register-appointment/:doctorId',
        element: <AppointmentRegistrationPage />,
      },
      {
        path: 'approval-status',
        element: <ApprovalStatusPage />,
      },
    ],
  },

  // Doctor routes
  {
    path: '/doctor',
    element: (
      <ProtectedRoute allowedRole="doctor">
        <DoctorLayout />
      </ProtectedRoute>
    ),
    children: [
      {
        index: true,
        element: <Navigate to="/doctor/dashboard" replace />,
      },
      {
        path: 'dashboard',
        element: <DoctorDashboard />,
      },
      {
        path: 'appointments',
        element: <ManageAppointmentsPage />,
      },
      {
        path: 'profile',
        element: <DoctorProfilePage />,
      },
    ],
  },

  // 404 fallback
  {
    path: '*',
    element: <Navigate to="/" replace />,
  },
]);