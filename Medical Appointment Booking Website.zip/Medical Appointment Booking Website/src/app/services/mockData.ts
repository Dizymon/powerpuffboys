// Mock data for the medical appointment system

export interface Doctor {
  id: string;
  name: string;
  specialization: string;
  credentials: string;
  description: string;
  availability: {
    day: string;
    slots: string[];
  }[];
  image?: string;
}

export interface Appointment {
  id: string;
  patientId: string;
  doctorId: string;
  patientName: string;
  contactNumber: string;
  email: string;
  gender: string;
  age: string;
  reason: string;
  date: string;
  timeSlot: string;
  status: 'pending' | 'approved' | 'rejected';
  doctorNotes?: string;
}

export interface AppointmentSlot {
  id: string;
  doctorId: string;
  date: string;
  timeSlot: string;
  available: boolean;
}

// LocalStorage keys
const DOCTORS_KEY = 'medicalApp_doctors';
const APPOINTMENTS_KEY = 'medicalApp_appointments';
const SLOTS_KEY = 'medicalApp_slots';

// Initialize doctors data
const defaultDoctors: Doctor[] = [
  {
    id: 'doctor-1',
    name: 'Dr. Sarah Johnson',
    specialization: 'General Medicine',
    credentials: 'MD, Board Certified in Internal Medicine',
    description: 'Experienced physician with over 10 years of practice. Specializes in preventive care, chronic disease management, and general health consultations.',
    availability: [
      { day: 'Monday', slots: ['9:00 AM', '10:00 AM', '2:00 PM', '3:00 PM'] },
      { day: 'Wednesday', slots: ['9:00 AM', '11:00 AM', '1:00 PM', '4:00 PM'] },
      { day: 'Friday', slots: ['10:00 AM', '2:00 PM', '3:00 PM'] }
    ]
  },
  {
    id: 'doctor-2',
    name: 'Dr. Michael Chen',
    specialization: 'Cardiology',
    credentials: 'MD, Board Certified Cardiologist',
    description: 'Specialist in heart health, cardiac screenings, and cardiovascular disease prevention. Dedicated to keeping your heart healthy.',
    availability: [
      { day: 'Tuesday', slots: ['9:00 AM', '10:30 AM', '2:00 PM', '3:30 PM'] },
      { day: 'Thursday', slots: ['9:00 AM', '11:00 AM', '1:00 PM', '3:00 PM'] },
      { day: 'Saturday', slots: ['9:00 AM', '10:00 AM', '11:00 AM'] }
    ]
  },
  {
    id: 'doctor-3',
    name: 'Dr. Emily Rodriguez',
    specialization: 'Dermatology',
    credentials: 'MD, Board Certified Dermatologist',
    description: 'Expert in skin conditions, cosmetic dermatology, and dermatological procedures. Committed to your skin health.',
    availability: [
      { day: 'Monday', slots: ['8:00 AM', '11:00 AM', '2:00 PM'] },
      { day: 'Tuesday', slots: ['8:00 AM', '1:00 PM', '3:00 PM'] },
      { day: 'Thursday', slots: ['8:00 AM', '10:00 AM', '2:00 PM'] }
    ]
  },
  {
    id: 'doctor-4',
    name: 'Dr. James Williams',
    specialization: 'Pediatrics',
    credentials: 'MD, Board Certified Pediatrician',
    description: 'Caring physician specialized in children\'s health. Creates a comfortable and friendly environment for young patients.',
    availability: [
      { day: 'Monday', slots: ['10:00 AM', '11:00 AM', '3:00 PM', '4:00 PM'] },
      { day: 'Wednesday', slots: ['10:00 AM', '2:00 PM', '3:00 PM', '4:00 PM'] },
      { day: 'Friday', slots: ['9:00 AM', '10:00 AM', '11:00 AM', '2:00 PM'] }
    ]
  },
  {
    id: 'doctor-5',
    name: 'Dr. Lisa Anderson',
    specialization: 'Orthopedics',
    credentials: 'MD, Board Certified Orthopedic Surgeon',
    description: 'Specialist in bone and joint health, sports injuries, and orthopedic surgery. Helping you move better.',
    availability: [
      { day: 'Tuesday', slots: ['8:00 AM', '10:00 AM', '1:00 PM', '3:00 PM'] },
      { day: 'Thursday', slots: ['8:00 AM', '9:00 AM', '2:00 PM', '4:00 PM'] },
      { day: 'Friday', slots: ['9:00 AM', '11:00 AM', '1:00 PM'] }
    ]
  }
];

// Initialize localStorage with default data if empty
function initializeLocalStorage() {
  if (!localStorage.getItem(DOCTORS_KEY)) {
    localStorage.setItem(DOCTORS_KEY, JSON.stringify(defaultDoctors));
  }
  if (!localStorage.getItem(APPOINTMENTS_KEY)) {
    const defaultAppointments: Appointment[] = [];
    localStorage.setItem(APPOINTMENTS_KEY, JSON.stringify(defaultAppointments));
  }
  if (!localStorage.getItem(SLOTS_KEY)) {
    localStorage.setItem(SLOTS_KEY, JSON.stringify([]));
  }
}

// Call initialization
initializeLocalStorage();

// Doctor service functions
export const doctorService = {
  getAll: (): Doctor[] => {
    const data = localStorage.getItem(DOCTORS_KEY);
    return data ? JSON.parse(data) : defaultDoctors;
  },
  
  getById: (id: string): Doctor | undefined => {
    const doctors = doctorService.getAll();
    return doctors.find(doctor => doctor.id === id);
  },
  
  updateProfile: (id: string, updates: Partial<Doctor>): Doctor | undefined => {
    const doctors = doctorService.getAll();
    const index = doctors.findIndex(d => d.id === id);
    if (index !== -1) {
      doctors[index] = { ...doctors[index], ...updates };
      localStorage.setItem(DOCTORS_KEY, JSON.stringify(doctors));
      return doctors[index];
    }
    return undefined;
  }
};

// Appointment service functions
export const appointmentService = {
  getAll: (): Appointment[] => {
    const data = localStorage.getItem(APPOINTMENTS_KEY);
    return data ? JSON.parse(data) : [];
  },
  
  getByPatientId: (patientId: string): Appointment[] => {
    const appointments = appointmentService.getAll();
    return appointments.filter(apt => apt.patientId === patientId);
  },
  
  getByDoctorId: (doctorId: string): Appointment[] => {
    const appointments = appointmentService.getAll();
    return appointments.filter(apt => apt.doctorId === doctorId);
  },
  
  getPending: (doctorId: string): Appointment[] => {
    const appointments = appointmentService.getAll();
    return appointments.filter(apt => apt.doctorId === doctorId && apt.status === 'pending');
  },
  
  create: (appointment: Omit<Appointment, 'id'>): Appointment => {
    const appointments = appointmentService.getAll();
    const newAppointment = {
      ...appointment,
      id: `apt-${Date.now()}`
    };
    appointments.push(newAppointment);
    localStorage.setItem(APPOINTMENTS_KEY, JSON.stringify(appointments));
    return newAppointment;
  },
  
  updateStatus: (id: string, status: 'approved' | 'rejected', notes?: string): Appointment | undefined => {
    const appointments = appointmentService.getAll();
    const index = appointments.findIndex(apt => apt.id === id);
    if (index !== -1) {
      appointments[index] = {
        ...appointments[index],
        status,
        doctorNotes: notes
      };
      localStorage.setItem(APPOINTMENTS_KEY, JSON.stringify(appointments));
      return appointments[index];
    }
    return undefined;
  },
  
  delete: (id: string): boolean => {
    const appointments = appointmentService.getAll();
    const index = appointments.findIndex(apt => apt.id === id);
    if (index !== -1) {
      appointments.splice(index, 1);
      localStorage.setItem(APPOINTMENTS_KEY, JSON.stringify(appointments));
      return true;
    }
    return false;
  }
};

// Appointment Slot service functions
export const slotService = {
  getAll: (): AppointmentSlot[] => {
    const data = localStorage.getItem(SLOTS_KEY);
    return data ? JSON.parse(data) : [];
  },
  
  getByDoctorId: (doctorId: string): AppointmentSlot[] => {
    const slots = slotService.getAll();
    return slots.filter(slot => slot.doctorId === doctorId);
  },
  
  create: (slot: Omit<AppointmentSlot, 'id'>): AppointmentSlot => {
    const slots = slotService.getAll();
    const newSlot = {
      ...slot,
      id: `slot-${Date.now()}`
    };
    slots.push(newSlot);
    localStorage.setItem(SLOTS_KEY, JSON.stringify(slots));
    return newSlot;
  },
  
  update: (id: string, updates: Partial<AppointmentSlot>): AppointmentSlot | undefined => {
    const slots = slotService.getAll();
    const index = slots.findIndex(s => s.id === id);
    if (index !== -1) {
      slots[index] = { ...slots[index], ...updates };
      localStorage.setItem(SLOTS_KEY, JSON.stringify(slots));
      return slots[index];
    }
    return undefined;
  },
  
  delete: (id: string): boolean => {
    const slots = slotService.getAll();
    const index = slots.findIndex(s => s.id === id);
    if (index !== -1) {
      slots.splice(index, 1);
      localStorage.setItem(SLOTS_KEY, JSON.stringify(slots));
      return true;
    }
    return false;
  }
};